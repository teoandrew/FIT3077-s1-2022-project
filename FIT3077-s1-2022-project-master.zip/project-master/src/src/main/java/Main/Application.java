package Main;

import java.io.IOException;
import java.util.Scanner;

import API.SiteSearchFacade;
import Model.People.Login;
import View.ConsoleText;

/**
 * Application class
 * This class represents the main application.
 */
public class Application {

    // jamesli42 - CUSTOMER
    // ayyy100 - CUSTOMER
    // ronlow - ADMIN c3ad290c-4e46-403b-b258-bdd1c3c3b9f7
    // simpylawesome - ADMIN - 929118aa-ca3b-434f-864f-21a10e26f70a
    // danto87 - ADMIN - 7fbd25ee-5b64-4720-b1f6-4f6d4731260e
    // kevink - ADMIN - 929118aa-ca3b-434f-864f-21a10e26f70a


    // Default interface to start off our application
    ConsoleText chatBox = new ConsoleText();
    public static Application application;

    public static Application getInstance(){
        if(application == null){
            application = new Application();
        }
        return application;
    }
    private Application(){}

    public void displayMenu(){
        Scanner input = new Scanner(System.in);
        String option, username, password;
        boolean condition = false;

        while (!condition) {
            this.displayOptions();
            System.out.print(">> Please pick an option: ");
            option = input.nextLine();

            switch(option){
                case "1" -> {
                    chatBox.printBox("(!) User Login",
                            "Important: Your input is case-sensitive!");
                    System.out.print(">> Please input your account username: ");
                    username = input.nextLine();

                    System.out.print(">> Please input your account password: ");
                    password = input.nextLine();

                    Login req = new Login(username, password);
                    try {
                        condition = req.authenticate();
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                }
                case "2" -> {
                    SiteSearchFacade search = new SiteSearchFacade();
                    search.searchSitePrompt();
                }
                case "3" -> {
                    chatBox.printBox("Thank you!");
                    condition = true;
                }
                default -> chatBox.printBox("Invalid Option!");
            }
        }
    }

    public void displayOptions(){
        chatBox.printBox("(!) Hi there!",
                "Welcome to COVID Testing Booking System",
                "",
                "What would you like to do today?",
                "(1) User Login",
                "(2) View Testing Sites",
                "(3) Exit This Application");
    }

    public static void main(String[] args) {
        Application app;
        app = Application.getInstance();
        app.displayMenu();
    }
}
