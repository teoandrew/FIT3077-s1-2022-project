package BookingInterface;

import API.BookingFacade;
import View.ConsoleText;
import org.json.*;
import java.net.http.HttpResponse;
import java.time.*;

import static API.API.api;

public class AdminInterface extends DefaultInterface{

    protected ConsoleText ct = new ConsoleText();
    protected BookingFacade bf1 = new BookingFacade();

    /*
        View
     */

    /**
     * Display all bookings across all testing sites.
     */
    public void viewAllBookings(){
        HttpResponse<String> response = api.getRequest("/booking");
        JSONArray jsonArray = new JSONArray(response.body());

        for(int i = 0; i < jsonArray.length(); i++){
            JSONObject objects = jsonArray.getJSONObject(i);
            bf1.search(objects.getString("id"), true);
        }
    }

    /**
     * Display a specific booking based on booking ID
     * @param identifier string, Booking ID
     */
    public void viewSpecificBooking(String identifier){
        HttpResponse<String> response = api.getRequest("/booking/" + identifier);
        if (response.statusCode() == 200) {
            bf1.search(identifier, true);
        } else {
            ct.printBox("(!) Booking with such Booking ID is not found! Please re-try!");
        }
    }

    /*
        Deletion
     */

    /**
     * Deletes a booking based on Booking ID
     * This action is not reversible.
     * @param identifier string, Booking ID
     * @param adminIdentifier string, Admin ID
     */
    public void deleteBooking(String identifier, String adminIdentifier){
        // Verify the booking ID
        HttpResponse<String> response = api.getRequest("/booking/" + identifier);
        Instant currentTime = Instant.now();
        if (response.statusCode() == 200) {
            JSONObject res = new JSONObject(response.body());
            String bookingFId = res.getString("id");
            String facilityId = res.getJSONObject("testingSite").getString("id");
            if(validateDate(response)) {
                // If the booking has not elapsed, delete it.
                HttpResponse<String> deleteResponse = api.deleteRequest("/booking/" + identifier);
                if (deleteResponse.statusCode() == 204) {
                    // If successful, we then store it in the admin's database and update accordingly
                    this.manageDeletedBooking(adminIdentifier, identifier, currentTime, facilityId);
                } else {
                    ct.printBox("(!) Booking deletion failed! Please re-try!");
                }
            } else {
                ct.printBox("(!) This booking has elapsed and can't be modified or deleted.");
            }
        } else {
            ct.printBox("(!) Booking with such Booking ID is not found! Please re-try!");
        }
    }

    /**
     * Helper function for deleteBooking()
     * 
     * Manages a deleted booking. 
     * Stores the deleted booking in the admin's database, 
     * update record of deleted bookings, update admin's record, etc.
     * 
     * @param adminIdentifier string, identifies an admin
     * @param identifier string, identifies a booking 
     * @param currentTime Instant, currentTime to record the date of deletion
     * @param facilityId string, identifies a facility
     */
    public void manageDeletedBooking(String adminIdentifier, String identifier, Instant currentTime, String facilityId){
        // If successful, we then store it in the admin's database,
        // corresponding to which admin deleted it
        HttpResponse<String> admin = api.getRequest("/user/" + adminIdentifier);
        JSONObject obj             = new JSONObject(admin.body());
        JSONArray arr              = obj.getJSONObject("additionalInfo").getJSONArray("modifications");
        String fId                 = obj.getJSONObject("additionalInfo").getString("facilityId");
        JSONArray deletedArr       = obj.getJSONObject("additionalInfo").getJSONArray("deletedBookings");
        // What has been deleted
        JSONObject deletion        = new JSONObject()
                .put("bookingId", identifier)
                .put("dateDeleted", currentTime)
                .put("facilityId", facilityId);
        // Put it in our array of deleted bookings
        deletedArr.put(deletion);
        // Put everything back in place along with the updated record of deleted bookings.
        JSONObject modifications   = new JSONObject()
                .put("facilityId", fId)
                .put("modifications", arr)
                .put("deletedBookings", deletedArr);
        // Place the object in the additional info section.
        JSONObject updateAdditionalInfo = new JSONObject()
                .put("additionalInfo", modifications);
        // Update the admin's record.
        api.patchRequest(updateAdditionalInfo.toString(), "/user/" + adminIdentifier);
        ct.printBox("(!) Booking with such Booking ID was successfully deleted.");
    }
}
