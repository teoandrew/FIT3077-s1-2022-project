package BookingInterface;

public class UserInterface extends DefaultInterface{
}
