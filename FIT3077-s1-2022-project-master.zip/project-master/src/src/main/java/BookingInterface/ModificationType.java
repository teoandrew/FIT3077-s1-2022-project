package BookingInterface;

public enum ModificationType {
    VENUE,
    TIMEDATE,
    CANCELLATION,
    INITIATED,
}
