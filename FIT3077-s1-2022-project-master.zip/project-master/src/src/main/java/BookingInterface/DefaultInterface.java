package BookingInterface;

import API.BookingFacade;
import Model.Booking.BookingStatus;
import View.ConsoleText;
import org.json.JSONArray;
import org.json.JSONObject;
import java.net.http.HttpResponse;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Scanner;
import static API.API.api;

public abstract class DefaultInterface {

    protected ConsoleText ct = new ConsoleText();
    protected BookingFacade bf1 = new BookingFacade();

    /*
        Validation
     */

    /**
     * Validates whether a booking has elapsed.
     * @param response booking response
     * @return boolean, false if booking has elapsed, true otherwise
     */
    public boolean validateDate(HttpResponse<String> response){
        // Validate whether the date of a booking has elapsed.
        JSONObject json = new JSONObject(response.body());
        Instant current = Instant.now();
        Instant bookingTime = Instant.parse(json.getString("startTime"));
        return current.compareTo(bookingTime) <= 0;
    }

    public boolean isStaff(String identifier){
        HttpResponse<String> response = api.getRequest("/user/" + identifier);
        if (response.statusCode() == 200){
            JSONObject user = new JSONObject(response.body());
            return !user.getBoolean("isCustomer");
        } else {
            ct.printBox("Invalid User ID.");
            return false;
        }
    }

    /*
        Modifications
     */

    /**
     * Modify Booking Time and automatically adds it to the modification record of the user.
     * Only the last 3 records are saved, the oldest record is automatically removed when > 3 records present.
     * ASSUMPTION: We assume that no booking can be completed if the starting time has not elapsed. Thus, no verification is required.
     * and no changes will be allowed as soon as the time has elapsed.
     * @param identifier string, Booking ID
     * @param isRevert boolean, whether this is a revert or not
     * @param selection int, which modification to revert, if available
     */
    public void modifyBookingTime(String identifier, boolean isRevert, int selection){
        ct.printBox("(!) You are currently modifying a Booking's Date/Time",
                "Please ensure that your input Date/Time has not elapsed AND",
                "is in the current format:",
                "Date: YYYY-MM-DD",
                "Time: HH:MM (In 24HRS Format)");

        Scanner input = new Scanner(System.in);
        String date, time;
        try {
            // Input
            System.out.print("Please enter your desired date: ");
            date = input.nextLine();
            System.out.print("Please enter your desired time: ");
            time = input.nextLine();

            // Date formatting
            String strDateTime = date + "T" + time;
            LocalDateTime ldt = LocalDateTime.parse(strDateTime);
            Instant instant = ldt.atZone(ZoneId.systemDefault()).toInstant();
            Instant current = Instant.now();

            // Verify booking id
            HttpResponse<String> response = api.getRequest("/booking/" + identifier);

            // Verify booking id is valid AND booking has not elapsed AND the modified date is valid
            if(response.statusCode() == 200 && current.compareTo(instant) <= 0 && validateDate(response)){
                JSONObject user = new JSONObject(response.body());
                Instant bookingTime = Instant.parse(user.getString("startTime"));
                String uId = user.getJSONObject("customer").getString("id");
                String fId = user.getJSONObject("testingSite").getString("id");
                JSONObject updateDate = new JSONObject()
                        .put("startTime", instant.toString());
                HttpResponse<String> update = api.patchRequest(updateDate.toString(), "/booking/" + identifier);
                if (update.statusCode() == 200) {
                    ct.printBox("(!) Booking Date/Time Successfully Updated!");
                    // Place this under the modification made by the user.
                    if (isStaff(uId)){
                        this.updateStaffModifications(uId, identifier, ModificationType.TIMEDATE, Instant.now().toString(), bookingTime.toString(), instant.toString(), fId, isRevert, selection);
                    } else {
                        this.updateModifications(uId, identifier, ModificationType.TIMEDATE, Instant.now().toString(), bookingTime.toString(), instant.toString(), fId, isRevert, selection);
                    }
                } else {
                    ct.printBox("(!) Booking update failed! Please re-try!");
                }
            } else {
                ct.printBox("(!) Invalid Booking ID OR the date/time has elapsed OR this booking is not modifiable!");
            }
        } catch (Exception e){
            System.out.println("Invalid input format!");
        }
    }
    
    /**
     * Modify Booking Time and automatically adds it to the modification record of the user.
     * Only the last 3 records are saved, the oldest record is automatically removed when > 3 records present.
     * ASSUMPTION: We assume that no booking can be completed if the starting time has not elapsed. Thus, no verification is required.
     * and no changes will be allowed as soon as the time has elapsed.
     * @param identifier string, Booking ID
     * @param inputTime string, input time to be modified
     * @param isRevert boolean, whether this is a revert or not
     * @param selection int, which modification to revert, if available
     */
    public void modifyBookingTimeWithInputTime(String identifier, String inputTime, boolean isRevert, int selection){
        LocalDateTime ldt = LocalDateTime.parse(inputTime);
        Instant instant = ldt.atZone(ZoneId.systemDefault()).toInstant();
        Instant current = Instant.now();
        System.out.println(instant + " " + current);
        HttpResponse<String> response = api.getRequest("/booking/" + identifier);
        System.out.println(current.compareTo(instant));
        if(response.statusCode() == 200 && current.compareTo(instant) <= 0 && validateDate(response)){
            JSONObject user = new JSONObject(response.body());
            String fId = user.getJSONObject("testingSite").getString("id");
            Instant bookingTime = Instant.parse(user.getString("startTime"));
            String uId = user.getJSONObject("customer").getString("id");
            JSONObject updateDate = new JSONObject()
                    .put("startTime", instant.toString());
            HttpResponse<String> update = api.patchRequest(updateDate.toString(), "/booking/" + identifier);
            if (update.statusCode() == 200) {
                ct.printBox("(!) Booking Date/Time Successfully Updated!");
                // Place this under the modification made by the user.
                if (isStaff(uId)){
                    this.updateStaffModifications(uId, identifier, ModificationType.TIMEDATE, Instant.now().toString(), bookingTime.toString(), instant.toString(), fId, isRevert, selection);
                } else {
                    this.updateModifications(uId, identifier, ModificationType.TIMEDATE, Instant.now().toString(), bookingTime.toString(), instant.toString(), fId, isRevert, selection);
                }
            } else {
                ct.printBox("(!) Booking update failed! Please re-try!");
            }
        } else {
            ct.printBox("(!) Invalid Booking ID OR the date/time has elapsed OR this booking is not modifiable!");
        }
    }

    /**
     * Modify A Booking Venue and automatically adds it to the modification record of the user.
     * Only the last 3 records are saved, the oldest record is automatically removed when > 3 records present.
     * ASSUMPTION: We assume that no booking can be completed if the starting time has not elapsed. Thus, no verification is required.
     * and no changes will be allowed as soon as the time has elapsed.
     * @param identifier string, Booking ID
     * @param input string, input venue to be modified
     * @param isRevert boolean, whether this is a revert or not
     * @param selection int, which modification to revert, if available
     */
    public void modifyBookingVenue(String identifier, String input, boolean isRevert, int selection){
        // Verify Booking ID
        HttpResponse<String> response = api.getRequest("/booking/" + identifier);
        if (response.statusCode() == 200) {
            JSONObject user = new JSONObject(response.body());
            String uId      = user.getJSONObject("customer").getString("id");
            String tId      = user.getJSONObject("testingSite").getString("id");
            if(validateDate(response)) {
                // Update Venue
                HttpResponse<String> siteVerify = api.getRequest("/testing-site/" + input);
                if (siteVerify.statusCode() == 200){
                    JSONObject updatedSite = new JSONObject(siteVerify.body());
                    JSONObject updSite = new JSONObject()
                            .put("testingSiteId", updatedSite.get("id"));
                    // API automatically updates the updatedAt time

                    HttpResponse<String> update = api.patchRequest(updSite.toString(), "/booking/" + identifier);
                    if (update.statusCode() == 200) {
                        ct.printBox("(!) Booking Venue Successfully Updated!");
                        // Place this under the modification made by the user.
                        if (isStaff(uId)){
                            this.updateStaffModifications(uId, identifier, ModificationType.VENUE, Instant.now().toString(), tId, input, input, isRevert, selection);
                        }
                        else {
                            this.updateModifications(uId, identifier, ModificationType.VENUE, Instant.now().toString(), tId, input, input, isRevert, selection);
                        }
                    } else {
                        ct.printBox("(!) Booking update failed! Please re-try!");
                    }
                }
                else {
                    ct.printBox("(!) Invalid testing site! Please re-try!");
                }

            } else {
                ct.printBox("(!) This booking has elapsed and can't be modified or deleted.");
            }
        } else {
            ct.printBox("(!) Booking with such Booking ID is not found! Please re-try!");
        }
    }

    /*
        Cancellation
     */

    /**
     * Cancels a booking based on Booking ID
     * This action can be reverted if the time has not elapsed.
     * @param identifier string, Booking ID
     */
    public void cancelBooking(String identifier){
        HttpResponse<String> response = api.getRequest("/booking/" + identifier);
        if (response.statusCode() == 200) {
            if(validateDate(response)) {
                JSONObject user = new JSONObject(response.body());
                String uId = user.getJSONObject("customer").getString("id");
                String fId = user.getJSONObject("testingSite").getString("id");
                JSONObject updStatus = new JSONObject()
                        .put("status", BookingStatus.CANCELLED.toString());
                HttpResponse<String> update = api.patchRequest(updStatus.toString(), "/booking/" + identifier);
                if (update.statusCode() == 200) {
                    ct.printBox("(!) Booking Successfully Cancelled!");
                    // Place this under the modification made by the user.
                    this.updateModifications(uId, identifier, ModificationType.CANCELLATION, Instant.now().toString(), "INITIATED", "CANCELLED", fId, false , -1);
                } else {
                    ct.printBox("(!) Booking cancellation failed! Please re-try!");
                }
            } else {
                ct.printBox("(!) This booking has elapsed and can't be modified or deleted.");
            }
        } else {
            ct.printBox("(!) Booking with such Booking ID is not found! Please re-try!");
        }
    }

    /*
        Update Modifications
     */

    /**
     * Processes a modification and update its records.
     * @param userId string, user ID
     * @param bId string, booking ID
     * @param type ModificationType
     * @param date string, date of modification
     * @param initialValue string, initial value
     * @param newValue string, modified value
     * @param facilityId string,facility ID
     * @param isRevert boolean, is this modification part of a revert?
     * @param selection selection, if isRevert is true, which modification is this?
     */
    public void updateModifications(String userId, String bId, ModificationType type, String date, String initialValue, String newValue, String facilityId, boolean isRevert, int selection){
        // Update the record of a modification after a specific modification was made to or by the user.
        HttpResponse<String> getModifications   = api.getRequest("/user/" + userId);
        JSONObject obj                          = new JSONObject(getModifications.body());
        JSONArray arr                           = obj.getJSONObject("additionalInfo").getJSONArray("modifications");
        JSONArray revertArr                     = obj.getJSONObject("additionalInfo").getJSONArray("reverted");
        if (isRevert) {
            this.revertModification(arr, selection, revertArr, userId);
        } else {
            if (arr.length() < 3) {
                this.recordModification(bId, type, date, initialValue, newValue, facilityId, arr, revertArr, userId);
            } else if (arr.length() == 3) {
                arr.remove(0);
                JSONObject newModification = new JSONObject()
                        .put("bookingId", bId)
                        .put("type", type.toString())
                        .put("dateModified", date)
                        .put("initialValue", initialValue)
                        .put("newValue", newValue)
                        .put("facilityId", facilityId);
                arr.put(arr.length(), newModification);
                JSONObject finalizedModification = new JSONObject()
                        .put("modifications", arr)
                        .put("reverted", revertArr);
                JSONObject updateAdditionalInfo = new JSONObject()
                        .put("additionalInfo", finalizedModification);
                HttpResponse<String> updateModifications = api.patchRequest(updateAdditionalInfo.toString(), "/user/" + userId);
                if (updateModifications.statusCode() == 200) {
                    ct.printBox("(!) Modification successful and added to record!");
                } else {
                    ct.printBox("(!) Modification failed to be recorded!");
                }
            }
        }
    }

    /**
     * Helper function for updateModifications
     * Reverts a modification
     * 
     * @param arr JSONArray, array for values in modifications field in additionalInfo field for a given user
     * @param selection int, if isRevert is true, which modification is this?
     * @param revertArr JSONArray, array for values in reverted field in additionalInfo field for a given user
     * @param userId String, identifies a user
     * 
     * @see updateModifications main method for updating modifications in DefaultInterface
     */
    public void revertModification(JSONArray arr, int selection, JSONArray revertArr, String userId){
        JSONObject current = (JSONObject) arr.get(selection-1);
        String nValue, fId, mType, iValue, bookingId;

        nValue = current.getString("newValue");
        fId = current.getString("facilityId");
        mType = current.getString("type");
        iValue = current.getString("initialValue");
        bookingId = current.getString("bookingId");

        JSONObject revert = new JSONObject()
                .put("dateModified", Instant.now())
                .put("from", nValue).put("to", iValue).put("bookingId", bookingId).put("mType", mType).put("facilityId", fId);
        revertArr.put(revertArr.length(), revert);
        arr.remove(selection - 1);
        JSONObject finalizedModification = new JSONObject()
                .put("modifications", arr)
                .put("reverted", revertArr);
        JSONObject updateAdditionalInfo = new JSONObject()
                .put("additionalInfo", finalizedModification);
        HttpResponse<String> updateModifications = api.patchRequest(updateAdditionalInfo.toString(), "/user/" + userId);
        if (updateModifications.statusCode() == 200) {
            ct.printBox("(!) Previous modification was reverted!");
        } else {
            ct.printBox("(!) Modification failed to revert!");
        }
    }

    /**
     * /**
     * Helper function for updateModifications
     * Records a modification
     * 
     * @param bId string, booking ID
     * @param type ModificationType
     * @param date string, date of modification
     * @param initialValue string, initial value
     * @param newValue string, modified value
     * @param facilityId string,facility ID
     * @param arr JSONArray, array for values in modifications field in additionalInfo field for a given user
     * @param revertArr JSONArray, array for values in reverted field in additionalInfo field for a given user
     * @param userId String, identifies a user
     * 
     * @see updateModifications main method for updating modifications in DefaultInterface
     */
    public void recordModification(String bId, ModificationType type, String date, String initialValue, String newValue, String facilityId, JSONArray arr, JSONArray revertArr, String userId){
        JSONObject newModification = new JSONObject()
                .put("bookingId", bId)
                .put("type", type.toString())
                .put("dateModified", date)
                .put("initialValue", initialValue)
                .put("newValue", newValue)
                .put("facilityId", facilityId);
        arr.put(arr.length(), newModification);
        JSONObject finalizedModification = new JSONObject()
                .put("modifications", arr)
                .put("reverted", revertArr);
        JSONObject updateAdditionalInfo = new JSONObject()
                .put("additionalInfo", finalizedModification);
        HttpResponse<String> updateModifications = api.patchRequest(updateAdditionalInfo.toString(), "/user/" + userId);
        if (updateModifications.statusCode() == 200) {
            ct.printBox("(!) Modification successful and added to record!");
        } else {
            ct.printBox("(!) Modification failed to be recorded!");
        }
    }


    /*
        Revert
     */

    /**
     * Reverts a particular modification based on which modification ID
     * @param uId string, user ID
     * @param selection int, modification to be reverted
     */
    public void revertModification(String uId, int selection){
        // Verify User ID
        HttpResponse<String> response = api.getRequest("/user/" + uId);

        if (response.statusCode() == 200){
            String type, initial, bId;
            JSONObject obj     = new JSONObject(response.body());
            JSONArray arr      = obj.getJSONObject("additionalInfo").getJSONArray("modifications");
            JSONObject current = arr.getJSONObject(selection-1);

            // Obtain what has been modified previously
            type    = current.getString("type");
            initial = current.getString("initialValue");
            System.out.println(initial);
            bId     = current.getString("bookingId");

            // Verify what type of change it was and make modifications based on type
            switch (type) {
                case "VENUE"     -> this.modifyBookingVenue(bId, initial, true, selection);
                case "TIMEDATE"  -> this.modifyBookingTimeWithInputTime(bId, initial.replaceAll("Z", ""), true, selection);
                case "CANCELLATION" -> {
                    // If it was cancelled, we can initialize it back if the date has not elapsed
                    response = api.getRequest("/booking/" + bId);
                    if (response.statusCode() == 200) {
                        if (validateDate(response)) {
                            // Re-initialize booking
                            JSONObject updStatus = new JSONObject()
                                    .put("status", ModificationType.INITIATED.toString());
                            HttpResponse<String> update = api.patchRequest(updStatus.toString(), "/booking/" + bId);
                            if (update.statusCode() == 200) {
                                JSONObject user = new JSONObject(update.body());
                                String fId = user.getJSONObject("testingSite").getString("id");
                                ct.printBox("(!) Booking Successfully Reverted From Cancelled to Initiated!");
                                // Place this under the modifications made by the user.
                                if(isStaff(uId)){
                                    this.updateStaffModifications(uId, bId, ModificationType.INITIATED, Instant.now().toString(), "CANCELLED", "INITIATED", fId, true, selection);
                                } else {
                                    this.updateModifications(uId, bId, ModificationType.INITIATED, Instant.now().toString(), "CANCELLED", "INITIATED", fId, true, selection);
                                }
                            } else {
                                ct.printBox("(!) Booking revert failed! Please re-try!");
                            }
                        } else {
                            ct.printBox("(!) This booking has elapsed and can't be modified or deleted.");
                        }
                    } else {
                        ct.printBox("(!) Booking with such Booking ID is not found! Please re-try!");
                    }
                }
            }
        } else {
            ct.printBox("(!) User does not exist. Please re-try!");
        }

    }

    public void updateStaffModifications(String userId, String bId, ModificationType type, String date, String initialValue, String newValue, String facilityId,  boolean isRevert, int selection){
        HttpResponse<String> getModifications = api.getRequest("/user/" + userId);
        JSONObject obj          = new JSONObject(getModifications.body());
        JSONArray arr           = obj.getJSONObject("additionalInfo").getJSONArray("modifications");
        JSONObject fId          = obj.getJSONObject("additionalInfo").getJSONObject("facilityId");
        JSONArray deletedArr    = obj.getJSONObject("additionalInfo").getJSONArray("deletedBookings");
        JSONArray revertArr     = obj.getJSONObject("additionalInfo").getJSONArray("reverted");
        if (isRevert){

            JSONObject currentRevert = (JSONObject) revertArr.get(selection-1);
            String nValue, facId, mType, iValue, bookingId;

            nValue = currentRevert.getString("newValue");
            facId = currentRevert.getString("facilityId");
            mType = currentRevert.getString("type");
            iValue = currentRevert.getString("initialValue");
            bookingId = currentRevert.getString("bookingId");

            JSONObject revert = new JSONObject()
                    .put("dateModified", Instant.now())
                    .put("from", nValue).put("to", iValue).put("bookingId", bookingId).put("mType", mType).put("facilityId", facId);
            revertArr.put(revertArr.length(), revert);

            arr.remove(selection - 1);
            JSONObject finalizedModification = new JSONObject()
                    .put("facilityId", fId)
                    .put("modifications", arr)
                    .put("deletedBookings", deletedArr)
                    .put("reverted", revertArr);
            JSONObject update = new JSONObject()
                    .put("additionalInfo", finalizedModification);

            HttpResponse<String> request = api.patchRequest(update.toString(), "/user/" + userId);
            if (request.statusCode() == 200){
                ct.printBox("(!) Previous modification was reverted!");
            } else {
                ct.printBox("(!) Modification failed to revert!");
            }
        } else {
            if (arr.length() < 3) {
                JSONObject newModification = new JSONObject()
                        .put("bookingId", bId)
                        .put("type", type.toString())
                        .put("dateModified", date)
                        .put("initialValue", initialValue)
                        .put("newValue", newValue)
                        .put("facilityId", facilityId);
                arr.put(arr.length(), newModification);
                JSONObject finalizedModification = new JSONObject()
                        .put("modifications", arr)
                        .put("facilityId", fId)
                        .put("deletedBookings", deletedArr)
                        .put("reverted", revertArr);
                JSONObject updateAdditionalInfo = new JSONObject()
                        .put("additionalInfo", finalizedModification);
                HttpResponse<String> updateModifications = api.patchRequest(updateAdditionalInfo.toString(), "/user/" + userId);
                if (updateModifications.statusCode() == 200) {
                    ct.printBox("(!) Modification successful and added to record!");
                } else {
                    ct.printBox("(!) Modification failed to be recorded!");
                }
            } else if (arr.length() == 3) {
                arr.remove(0);
                JSONObject newModification = new JSONObject()
                        .put("bookingId", bId)
                        .put("type", type.toString())
                        .put("dateModified", date)
                        .put("initialValue", initialValue)
                        .put("newValue", newValue)
                        .put("facilityId", facilityId);
                arr.put(arr.length(), newModification);
                JSONObject finalizedModification = new JSONObject()
                        .put("modifications", arr)
                        .put("facilityId", fId)
                        .put("deletedBookings", deletedArr)
                        .put("reverted", revertArr);
                JSONObject updateAdditionalInfo = new JSONObject()
                        .put("additionalInfo", finalizedModification);
                HttpResponse<String> updateModifications = api.patchRequest(updateAdditionalInfo.toString(), "/user/" + userId);
                if (updateModifications.statusCode() == 200) {
                    ct.printBox("(!) Modification successful and added to record!");
                } else {
                    ct.printBox("(!) Modification failed to be recorded!");
                }
            }
        }
    }
}
