package View;

public class BookingView {
    protected ConsoleText ct = new ConsoleText();

    public BookingView(){}

    public void printBookingDetails() {
    }
}