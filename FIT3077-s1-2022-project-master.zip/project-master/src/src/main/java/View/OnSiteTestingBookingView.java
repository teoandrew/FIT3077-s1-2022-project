package View;

public class OnSiteTestingBookingView {
    protected ConsoleText ct = new ConsoleText();

    public OnSiteTestingBookingView(){}

    public void printOnSiteTestingBookingDetails() {
    }
}
