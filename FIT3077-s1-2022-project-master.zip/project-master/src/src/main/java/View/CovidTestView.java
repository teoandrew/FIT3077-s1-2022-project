package View;

public class CovidTestView {
    protected ConsoleText ct = new ConsoleText();

    public CovidTestView(){}

    public void printCovidTestDetails() {
    }
}
