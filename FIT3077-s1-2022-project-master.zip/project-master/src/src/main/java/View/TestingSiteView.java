package View;

public class TestingSiteView {
    protected ConsoleText ct = new ConsoleText();

    public TestingSiteView(){}

    public void printTestingSiteDetails() {
    }
}
