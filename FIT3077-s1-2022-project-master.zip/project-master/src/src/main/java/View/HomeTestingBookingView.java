package View;

public class HomeTestingBookingView {
    protected ConsoleText ct = new ConsoleText();

    public HomeTestingBookingView(){}

    public void printHomeTestingDetails() {
    }
}
