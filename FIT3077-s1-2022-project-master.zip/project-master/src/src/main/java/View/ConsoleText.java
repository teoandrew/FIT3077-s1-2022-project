package View;

/**
 * ConsoleText class
 */
public class ConsoleText {

    // https://stackoverflow.com/questions/27977973/how-to-use-print-format-to-make-box-around-text-java

    private int getMaxLength(String... strings) {
        int len = Integer.MIN_VALUE;
        for (String str : strings) {
            len = Math.max(str.length(), len);
        }
        return len;
    }

    private String padString(String str, int len) {
        return str + fill(' ', len - str.length());
    }

    private String fill(char ch, int len) {
        return String.valueOf(ch).repeat(Math.max(0, len));
    }

    public void printBox(String... strings) {
        int maxBoxWidth = getMaxLength(strings);
        String line = "+" + fill('-', maxBoxWidth + 2) + "+";
        System.out.println(line);
        for (String str : strings) {
            System.out.printf("| %s |%n", padString(str, maxBoxWidth));
        }
        System.out.println(line);
    }

}
