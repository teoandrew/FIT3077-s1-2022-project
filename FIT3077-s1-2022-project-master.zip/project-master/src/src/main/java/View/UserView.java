package View;

public class UserView {
    protected ConsoleText ct = new ConsoleText();

    public UserView(){}

    public void printUserDetails() {
    }
}
