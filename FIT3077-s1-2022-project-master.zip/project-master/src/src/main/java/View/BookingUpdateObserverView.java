package View;
import java.time.LocalDateTime;
import java.util.Map;

public class BookingUpdateObserverView {

    protected ConsoleText ct = new ConsoleText();

    public void view(Map<LocalDateTime, String> sortedBookings,
                     Map<LocalDateTime, String> sortedModifications,
                     Map<LocalDateTime, String> sortedDeletions,
                     Map<LocalDateTime, String> sortedReverts){

        ct.printBox("(!) Booking Creation Updates:");
        for(Map.Entry<LocalDateTime, String> entry : sortedBookings.entrySet()){
            ct.printBox("New Booking Created On: " + entry.getKey(),
                    "Booking ID: " + entry.getValue());
        }

        ct.printBox("(!) Booking Modification Updates:");
        for (Map.Entry<LocalDateTime, String> entry : sortedModifications.entrySet()) {
            ct.printBox("Booking Modified On: " + entry.getKey(),
                    "Modification Details: " + entry.getValue());
        }

        ct.printBox("(!) Booking Deletion Updates:");
        for (Map.Entry<LocalDateTime, String> entry : sortedDeletions.entrySet()) {
            ct.printBox("Booking Deleted On: " + entry.getKey(),
                    "Deletion Details: " + entry.getValue());
        }

        ct.printBox("(!) Modification Revert Updates:");
        for (Map.Entry<LocalDateTime, String> entry : sortedReverts.entrySet()) {
            ct.printBox("Modification Reverted On: " + entry.getKey(),
                    "Reversion Details: " + entry.getValue());
        }

    }


}
