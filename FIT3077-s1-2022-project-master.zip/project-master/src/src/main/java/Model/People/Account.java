package Model.People;

import View.ConsoleText;

import org.json.JSONArray;
import org.json.JSONObject;

import API.API;

import java.net.http.HttpResponse;
import java.time.Instant;

/** 
 * User.User account class
 */
public class Account {

    private final User user;
    private final UserType userRole;

    protected API api = API.getInstance();
    protected ConsoleText ct = new ConsoleText();

    public Account(User user, UserType userRole){
        this.user = user;
        this.userRole = userRole;
    }

    public User getUser() {
        return user;
    }

    public String getRole(){
        return this.userRole.name();
    }

    /**
     * Validates whether a booking has elapsed.
     * @param response booking response
     * @return boolean, false if booking has elapsed, true otherwise
     */
    public boolean validateDate(String response){
        // Validate whether the date of a booking has elapsed.
        Instant current = Instant.now();
        Instant bookingTime = Instant.parse(response);
        return current.compareTo(bookingTime) <= 0;
    }

    /**
     * Gets all bookings directly from web service, corresponding to the user
     * //TODO: Perhaps include test results & etc.
     */
    public void getBookings(boolean requireActive) {
        ct.printBox("(!) Your Active Bookings: ");
        HttpResponse<String> response = api.getRequest("/user/" + this.getUser().getUserId() + "?fields=bookings");
        JSONObject json = new JSONObject(response.body());
        JSONArray jsonArr = new JSONArray(json.getJSONArray("bookings"));
        String bookingId, testingSiteId, testingSiteName, creationDate, updatedDate, status, smsPin, startingDate;

        for (int i = 0; i < jsonArr.length(); i++){
            status          = json.getJSONArray("bookings").getJSONObject(i).getString("status");
            bookingId       = jsonArr.getJSONObject(i).getString("id");
            testingSiteId   = jsonArr.getJSONObject(i).getJSONObject("testingSite").getString("id");
            testingSiteName = jsonArr.getJSONObject(i).getJSONObject("testingSite").getString("name");
            creationDate    = jsonArr.getJSONObject(i).getString("createdAt");
            updatedDate     = jsonArr.getJSONObject(i).getString("updatedAt");
            startingDate    = jsonArr.getJSONObject(i).getString("startTime");
            smsPin          = jsonArr.getJSONObject(i).getString("smsPin");
            if(requireActive) {
                if (!status.equals("COMPLETED") && this.validateDate(jsonArr.getJSONObject(i).getString("startTime"))) {
                    ct.printBox("Booking (" + (i + 1) + "):",
                            "Booking ID: " + bookingId,
                            "Testing Site ID: " + testingSiteId,
                            "Testing Site Name: " + testingSiteName,
                            "Booking Creation Date: " + creationDate,
                            "Booking Updated Date: " + updatedDate,
                            "Booking Starting Date: " + startingDate,
                            "Booking Status: " + status,
                            "Booking SMS PIN: " + smsPin);
                }
            } else {
                ct.printBox("Booking (" + (i + 1) + "):",
                        "Booking ID: " + bookingId,
                        "Testing Site ID: " + testingSiteId,
                        "Testing Site Name: " + testingSiteName,
                        "Booking Creation Date: " + creationDate,
                        "Booking Updated Date: " + updatedDate,
                        "Booking Starting Date: " + startingDate,
                        "Booking Status: " + status,
                        "Booking SMS PIN: " + smsPin);
            }
        }
    }
}
