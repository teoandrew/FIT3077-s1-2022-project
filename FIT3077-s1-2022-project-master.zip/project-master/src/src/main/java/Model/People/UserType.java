package Model.People;

public enum UserType {
    Customer,
    Administrator,
    Administer,
    Patient
}
