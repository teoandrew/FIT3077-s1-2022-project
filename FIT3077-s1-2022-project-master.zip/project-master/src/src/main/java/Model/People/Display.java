package Model.People;

import java.io.IOException;

public interface Display {

    void prompt();
    void displayOptions();
    void menu() throws IOException;
}
