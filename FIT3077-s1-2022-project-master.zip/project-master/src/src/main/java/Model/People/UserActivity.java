package Model.People;

public interface UserActivity {

    String viewAccountDetails();
    void viewBookings();
    void createOnSiteTestingBooking();
    void createHomeTestingBooking();
}
