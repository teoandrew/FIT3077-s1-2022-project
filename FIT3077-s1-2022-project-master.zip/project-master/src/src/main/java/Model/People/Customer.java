package Model.People;

import Main.Application;

import java.util.Scanner;

import API.SiteSearchFacade;

/**
 * Customer class
 */
public class Customer extends User{

    public Customer(String newFamName, String newGivName, String newUId, String newPhoneNum){
        super(newFamName, newGivName, newUId, newPhoneNum, UserType.Customer);
    }

    public String toString(){
        return "(!) Customer details: \n" + super.toString();
    }

    public void display(){
        ct.printBox(
                "(!) Customer Details",
                "Family name: "  + this.getFamilyName(),
                "Given name: "   + this.getGivenName(),
                "User ID: "      + this.getUserId(),
                "Phone Number: " + this.getPhoneNumber());
    }

    @Override
    public String viewAccountDetails() {
        return this.toString();
    }

    @Override
    public void displayOptions(){
        ct.printBox("Options Available: ",
                "(1) Make a System Booking",
                "(2) Make a Home Booking",
                "(3) Modify an Existing Booking",
                "(4) Revert a Modification",
                "(5) Search and View Testing Sites",
                "(6) View User Account Details",
                "(7) View Bookings Made",
                "(8) View Active Bookings",
                "(9) Log Out");
    }

    @Override
    public void menu(){
        String res;
        boolean exit = false;
        this.prompt();
        input = new Scanner(System.in);
        while (!exit) {
            this.displayOptions();
            System.out.print(">> Please pick an option: ");
            res = input.nextLine();
            switch (res) {
                case "1" -> this.createOnSiteTestingBooking();
                case "2" -> this.createHomeTestingBooking();
                case "3" -> {
                    boolean exit2 = false;
                    while (!exit2) {
                        ct.printBox("Options Available: ",
                                "(1) Modify Booking Venue",
                                "(2) Modify Booking Time",
                                "(3) Cancel Booking",
                                "(4) Quit View OR Modification");
                        System.out.print(">> Please pick an option: ");
                        res = input.nextLine();
                        switch (res){
                            case "1" -> {
                                String bId, tId;
                                ct.printBox("(!) Modify Booking Venue", "If you have a PIN, please exit and obtain the Booking ID first!");
                                this.getUserAcc().getBookings(true);
                                System.out.print(">> Please enter Booking ID: ");
                                bId = input.nextLine();
                                System.out.print(">> Please enter Site ID (to-be changed into): ");
                                tId = input.nextLine();
                                this.modifyBookingVenue(bId, tId, false, -1);
                            }
                            case "2" -> {
                                String bId;
                                ct.printBox("(!) Modify Booking Time", "If you have a PIN, please exit and obtain the ID first!");
                                this.getUserAcc().getBookings(true);
                                System.out.print(">> Please enter Booking ID: ");
                                bId = input.nextLine();
                                this.modifyBookingTime(bId, false, -1);
                            }
                            case "3" -> {
                                String bId;
                                ct.printBox("(!) Cancel A Booking", "If you have a PIN, please exit and obtain the Booking ID first!");
                                this.getUserAcc().getBookings(true);
                                System.out.print(">> Please enter Booking ID: ");
                                bId = input.nextLine();
                                this.cancelBooking(bId);
                            }
                            case "4" -> exit2 = true;
                        }
                    }
                }
                case "4" -> {
                    boolean cond = true;
                    while (cond) {
                        int selection;
                        ct.printBox("(!) Reverting a Modification");
                        cond = this.displayBookingModifications(this.getUserId());
                        if (cond) {
                            System.out.print(">> Please enter a modification to be reverted: ");
                            selection = Integer.parseInt(input.nextLine());
                            if (selection >= 1 && selection <= 3) {
                                this.revertModification(this.getUserId(), selection);
                                cond = false;
                            } else {
                                ct.printBox("(!) Please input a valid number.");
                            }
                        }
                    }
                }
                case "5" -> {
                    SiteSearchFacade site = new SiteSearchFacade();
                    site.searchSitePrompt();
                }
                case "6" -> this.display();
                case "7" -> this.viewBookings();
                case "8" -> this.viewActiveBookings();
                case "9" -> {
                    exit = true;
                    Application.getInstance().displayMenu();
                }
                default -> System.out.println("Invalid Input");
            }
        }
    }
}
