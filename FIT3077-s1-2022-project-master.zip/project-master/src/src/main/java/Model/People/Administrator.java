package Model.People;

import Controller.BookingUpdateObserverController;
import Main.Application;
import API.BookingFacade;
import API.SiteSearchFacade;
import BookingInterface.AdminInterface;
import BookingInterface.DefaultInterface;
import Model.Booking.*;

import View.BookingUpdateObserverView;
import org.json.JSONObject;

import java.io.IOException;
import java.net.http.HttpResponse;
import java.time.Instant;
import java.util.*;

/**
 * Administor class
 */
public class Administrator extends Staff {

    private final AdminInterface aI = new AdminInterface();
    private BookingUpdateObserverController bookingUpdates;
    private BookingFacade bf = new BookingFacade();

    /**
     * Constructor
     * @param newFamName string, family name
     * @param newGivName string, given name
     * @param newUId string, user ID
     * @param newPhoneNum string, user phone
     */
    public Administrator(String newFamName, String newGivName, String newUId, String newPhoneNum){
        super(newFamName, newGivName, newUId, newPhoneNum, UserType.Administrator);
    }

    /**
     * To String method
     * @return details of a user
     */
    public String toString(){
        return "(!) Administrator details: \n" + super.toString();
    }

    /**
     * View account information
     * @return string, account info
     */
    @Override
    public String viewAccountDetails() {
        return this.toString();
    }

    /**
     * Staff Assisted Booking creation
     */
    public void createStaffAssistedBooking(){
        // Display Prompt
        ct.printBox("(!) Staff Assisted Booking Creation");
        String custId, testSiteId, famName, givName, phoneNum;

        // Input Prompt
        input = new Scanner(System.in);
        System.out.print(">> Please input customer ID: ");
        custId = input.nextLine();
        System.out.print(">> Please input testing site ID: ");
        testSiteId = input.nextLine();

        // API Request to retrieve user
        HttpResponse<String> response = api.getRequest("/user/" + custId);

        // We assume everyone making a booking is a Customer
        // Extracting values from our JSON Object
        JSONObject json = new JSONObject(response.body());
        givName  = json.getString("givenName");
        famName  = json.getString("familyName");
        phoneNum = json.getString("phoneNumber");


        User cust = UserFactory.getUser(new CustomerFactory(famName, givName, custId, phoneNum));
        OnSiteTestingBooking booking = new OnSiteTestingBooking(cust, testSiteId);
        bookingFacade = new BookingFacade();
        bookingFacade.registerOnSiteBooking(cust, booking);

        // Display booking info after booking to allow the admin
        // to provide details about the user's booking.
        booking.extractPinCode();
        booking.bookingSuccessful();
    }

    /**
     * Verifies a customer's PIN
     * @throws IOException for input errors
     */
    public void verifyCustomerPIN() throws IOException{
        String pinCode;
        // Display prompt
        ct.printBox("(!) PIN Verification for ON-SITE Booking");
        input = new Scanner(System.in);

        // Input prompt
        System.out.print(">> Please input PIN Code provided by Customer: ");
        pinCode = input.nextLine();

        // Main.Main.API Response handled by Main.Main.API Class
        HttpResponse<String> response = api.getRequest("/booking");
        String id = api.responseSearch(response, "smsPin", pinCode, false);
        String currentTime = Instant.now().toString();

        // API Response handled by API Class with an additional JSON Object as our patch input
        // to update our Booking Object.
        if (id != null){
            // Removing the quotation marks upon retrieval
            id = id.substring(1, id.length() - 1);
            // When we make updates to a booking, we update its time.
            // When we verify a booking, we make the status as VERIFIED
            String items = new JSONObject()
                    .put("updatedAt", currentTime)
                    .put("status", "VERIFIED")
                    .toString();
            // Main.Main.API Request
            HttpResponse<String> res = api.patchRequest(items, "/booking/" + id);

            if (res.statusCode() == 200){
                // Typical Scenario
                ct.printBox("(!) Booking Verified and Updated!");
                this.displayBookingInfo(id);
            } else {
                // For internal testing purposes
                ct.printBox("(!) Booking Verification Failed due to Internal API Issues! Please re-try");
            }
        } else {
            // The PIN was invalid
            ct.printBox("(!) Booking with such Booking PIN is not found! Please re-try!");
        }

    }

    /**
     * Verifies a customer's QR code
     * @throws IOException for input errors
     */
    public void verifyCustomerQR() throws IOException {

        String qrCode;
        // Display prompt
        ct.printBox("(!) QR Verification for HOME Booking");
        input = new Scanner(System.in);

        // Input prompt
        System.out.print(">> Please input QR Code provided by Customer: ");
        qrCode = input.nextLine();

        // API Response handled by API Class
        HttpResponse<String> response = api.getRequest("/booking");
        String id = api.responseSearch(response, "qrCode", qrCode, true);

        // API Response handled by API Class with an additional JSON Object as our patch input
        // to update our Booking.Booking Object.
        if(id != null){
            // API-call to helper function, main purpose is to create additional JSON Objects
            // before we patch
            id = id.substring(1, id.length() - 1);
            response = verifyCustomerQRHelperFunction(qrCode, id);
            if(response.statusCode() == 200){
                // Typical Scenario
                ct.printBox("(!) Booking Verified and Updated!");
                this.displayBookingInfo(id);
            } else {
                // For internal testing purposes
                ct.printBox("(!) Booking Verification Failed due to Internal API Issues! Please re-try");
            }
        } else {
            // The QR was invalid
            ct.printBox("(!) Booking with such Booking QR is not found! Please re-try!");
        }
    }

    /**
     * Verify customer QR Helper
     * @param qrCode string, qrCode
     * @param identifier string, booking ID
     * @return a HTTPResponse
     */
    public HttpResponse<String> verifyCustomerQRHelperFunction(String qrCode, String identifier){
        // We create additional JSON Objects to update Array values
        // as well as our original attributes within our initial JSON Object
        String currentTime = Instant.now().toString();

        JSONObject additionalInfo = new JSONObject()
                .put("qrCode", qrCode)
                .put("requireRAT", true)
                .put("bookingType", "HOME")
                .put("collectedRAT", true);

        String items = new JSONObject()
                .put("updatedAt", currentTime)
                .put("status", "VERIFIED")
                .put("additionalInfo", additionalInfo)
                .toString();

        return api.patchRequest(items, "/booking/" + identifier);
    }


    /**
     * Retrieve real-time updates made to bookings
     * @see BookingUpdateObserverController
     */
    public void retrieveUpdates(){
        this.bookingUpdates = new BookingUpdateObserverController(new BookingUpdateObserver(this.retrieveFacilityId(this.getUserId())), new BookingUpdateObserverView());
        bookingUpdates.update();
        bookingUpdates.updateView();
    }

    /**
     * Converts a booking pin to booking ID for Admin convenience
     * @param pin string, booking PIN
     * @throws IOException for input errors
     * @see BookingFacade
     */
    public void pinToBookingID (String pin) throws IOException {
        bf.pinToBookingID(pin);
    }

    /**
     * View all bookings from an Admin perspective
     */
    public void viewAllBooking(){
        aI.viewAllBookings();
    }

    /**
     * View a specific booking from an Admin perspective
     * @param bookingId string, booking ID
     */
    public void viewSpecificBooking(String bookingId){
        aI.viewSpecificBooking(bookingId);
    }

    /**
     * Retrieves facility ID of a Staff
     * @param identifier string, staff ID
     * @return string, facility ID
     */
    public String retrieveFacilityId(String identifier){
        HttpResponse<String> user = api.getRequest("/user/" + identifier);
        JSONObject admin = new JSONObject(user.body());
        return admin.getJSONObject("additionalInfo").getString("facilityId");
    }

    /**
     * Displays booking modifications
     * @see BookingFacade
     */
    public boolean displayBookingModifications(String identifier){
        return bf.displayBookingModifications(identifier);
    }

    /**
     * Reverts a booking modification
     * @see DefaultInterface
     */
    public void revertModification(String uId, int selection){
        aI.revertModification(uId, selection);
    }

    /**
     * Deletes a booking
     * @see AdminInterface
     */
    public void deleteBooking(String bookingId){
        aI.deleteBooking(bookingId, this.getUserId());
    }

    /**
     * Modify a booking time
     * @see DefaultInterface
     */
    public void modifyBookingTime(String bookingId, boolean isRevert, int selection){
        aI.modifyBookingTime(bookingId, isRevert, selection);
    }

    /**
     * Modify a booking venue
     * @see DefaultInterface
     */
    public void modifyBookingVenue(String bookingId, String newVenue, boolean isRevert, int selection){
        aI.modifyBookingVenue(bookingId, newVenue, isRevert, selection);
    }

    /**
     * Cancels a booking based on Booking ID
     * @see DefaultInterface
     */
    public void cancelBooking(String bookingId){
        aI.cancelBooking(bookingId);
    }

    /**
     * Displays a particular booking information
     * @param identifier Booking ID
     */
    public void displayBookingInfo(String identifier){
        bf.search(identifier, true);
    }

    /**
     * Display all available actions for Admin
     */
    @Override
    public void displayOptions(){
        ct.printBox("Options Available: ",
                "(1) Make a System Booking",
                "(2) Make a Home Booking",
                "(3) Search and View Testing Sites",
                "(4) View User Account Details",
                "(5) View Bookings Made",
                "(6) View Active Bookings",
                "(7) Make a Staff Assisted Booking for Customer",
                "(8) Verify Customer Pin Code",
                "(9) Verify Customer QR Code",
                "(10) View OR Modify Bookings",
                "(11) Revert a Modification",
                "(12) Get Recent Updates (Limited to Today)",
                "(13) Log Out");
    }

    /**
     * Display the menu for Admin
     * @throws IOException for input errors
     */
    @Override
    public void menu() throws IOException {
        String res;
        boolean exit = false;
        this.prompt();
        input = new Scanner(System.in);
        while (!exit) {
            this.displayOptions();
            System.out.print(">> Please pick an option: ");
            res = input.nextLine();
            switch (res) {
                case "1" -> this.createOnSiteTestingBooking();
                case "2" -> this.createHomeTestingBooking();
                case "3" -> {
                    SiteSearchFacade site = new SiteSearchFacade();
                    site.searchSitePrompt();
                }
                case "4" -> this.display();
                case "5" -> this.viewBookings();
                case "6" -> this.viewActiveBookings();
                case "7" -> this.createStaffAssistedBooking();
                case "8" -> this.verifyCustomerPIN();
                case "9" -> this.verifyCustomerQR();
                case "10" -> {
                    boolean exit2 = false;
                    while (!exit2) {
                        ct.printBox("Options Available: ",
                                "(1) View All Available Bookings",
                                "(2) View Specific Booking",
                                "(3) Modify Booking Venue",
                                "(4) Modify Booking Time",
                                "(5) Cancel Booking",
                                "(6) Delete Booking",
                                "(7) Obtain Booking ID with Booking PIN",
                                "(8) Quit View OR Modification");
                        System.out.print(">> Please pick an option: ");
                        res = input.nextLine();
                        switch (res){
                            case "1" -> {
                                ct.printBox("(!) View All Bookings");
                                this.viewAllBooking();
                            }
                            case "2" -> {
                                ct.printBox("(!) View Specific Booking" ,"If you have a PIN, please exit and obtain the Booking ID first!");
                                System.out.print(">> Please enter Booking ID: ");
                                String bId;
                                bId = input.nextLine();
                                this.viewSpecificBooking(bId);
                            }
                            case "3" -> {
                                String bId, tId;
                                ct.printBox("(!) Modify Booking Venue", "If you have a PIN, please exit and obtain the Booking ID first!");
                                System.out.print(">> Please enter Booking ID: ");
                                bId = input.nextLine();
                                System.out.print(">> Please enter Site ID (to-be changed into): ");
                                tId = input.nextLine();
                                this.modifyBookingVenue(bId, tId, false, -1);
                            }
                            case "4" -> {
                                String bId;
                                ct.printBox("(!) Modify Booking Time", "If you have a PIN, please exit and obtain the ID first!");
                                System.out.print(">> Please enter Booking ID: ");
                                bId = input.nextLine();
                                this.modifyBookingTime(bId, false, -1);
                            }
                            case "5" -> {
                                String bId;
                                ct.printBox("(!) Cancel A Booking", "If you have a PIN, please exit and obtain the Booking ID first!");
                                System.out.print(">> Please enter Booking ID: ");
                                bId = input.nextLine();
                                this.cancelBooking(bId);
                            }
                            case "6" -> {
                                String bId;
                                ct.printBox("(!) Delete A Booking", "If you have a PIN, please exit and obtain the Booking ID first!");
                                System.out.print(">> Please enter Booking ID: ");
                                bId = input.nextLine();
                                this.deleteBooking(bId);
                            }
                            case "7" -> {
                                String pin;
                                ct.printBox("(!) Obtaining Booking ID");
                                System.out.print(">> Please enter Booking PIN: ");
                                pin = input.nextLine();
                                this.pinToBookingID(pin);
                            }
                            case "8" -> exit2 = true;
                        }
                    }
                }
                case "11" -> {
                    boolean cond = true;
                    while (cond) {
                        String bId;
                        int selection;
                        ct.printBox("(!) Reverting a Modification");
                        System.out.print(">> Please enter User ID: ");
                        bId = input.nextLine();
                        cond = this.displayBookingModifications(bId);
                        if (cond) {
                            System.out.print(">> Please enter a modification to be reverted: ");
                            selection = Integer.parseInt(input.nextLine());
                            if (selection >= 1 && selection <= 3) {
                                this.revertModification(bId, selection);
                                cond = false;
                            } else {
                                ct.printBox("(!) Please input a valid number.");
                            }
                        }
                    }
                }
                case "12" -> {
                    ct.printBox("(!) Live Updates for Today",
                            "Facility ID: " + this.retrieveFacilityId(this.getUserId()));
                    this.retrieveUpdates();
                }
                case "13" -> {
                    exit = true;
                    Application.getInstance().displayMenu();
                }
                default -> System.out.println("Invalid Input");
            }
        }
    }

}
