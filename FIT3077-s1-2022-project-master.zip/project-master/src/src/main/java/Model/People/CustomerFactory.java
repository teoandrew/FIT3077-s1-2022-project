package Model.People;

/**
 * Abstract factory class for Customer
 */
public class CustomerFactory implements UserAbstractFactory {

    private String familyName;
    private String givenName;
    private String userId;
    private String phoneNumber;

    public CustomerFactory(String newFamilyName, String newGivenName, String newUserId, String newPhoneNumber){
        this.familyName = newFamilyName;
        this.givenName = newGivenName;
        this.userId = newUserId;
        this.phoneNumber = newPhoneNumber;
    }

    @Override
    public User createUser() {
        return new Customer(familyName, givenName, userId, phoneNumber);
    }
}
