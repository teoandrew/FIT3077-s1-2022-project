package Model.People;

/**
 * Patient class
 */
public class Patient extends User {

    public Patient(String newFamName, String newGivName, String newUId, String newPhoneNum) {
        super(newFamName, newGivName, newUId, newPhoneNum, UserType.Patient);
    }

    @Override
    public String viewAccountDetails() {
        return this.toString();
    }

}
