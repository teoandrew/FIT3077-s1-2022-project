package Model.People;

public class UserFactory {

    public static User getUser(UserAbstractFactory factory){
        return factory.createUser();
    }

}
