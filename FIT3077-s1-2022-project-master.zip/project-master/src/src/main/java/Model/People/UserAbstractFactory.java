package Model.People;

public interface UserAbstractFactory {

    User createUser();
    
}
