package Model.People;

import Model.Booking.*;
import View.ConsoleText;

import java.io.IOException;
import java.net.http.HttpResponse;
import java.util.Scanner;

import API.API;
import API.BookingFacade;
import API.SiteSearchFacade;
import BookingInterface.DefaultInterface;
import BookingInterface.UserInterface;

/**
 * Abstract class for User
 */
public abstract class User implements UserActivity, Display {

    // User attributes
    private final String familyName;
    private final String givenName;
    private final String userId;
    private final String phoneNumber;
    private final Account userAcc;
    // Console GUI
    protected ConsoleText ct = new ConsoleText();
    protected Scanner input;
    protected API api = API.getInstance();
    protected BookingFacade bookingFacade = new BookingFacade();
    protected UserInterface userInterface = new UserInterface();

    public User(String newFamName, String newGivName, String newUId, String newPhoneNum, UserType userRole) {
        this.familyName = newFamName;
        this.givenName = newGivName;
        this.userId = newUId;
        this.phoneNumber = newPhoneNum;
        this.userAcc = new Account(this, userRole);
    }

    public String toString() {
        return "   >> Family Name: " + this.familyName
                + "\n   >> Given Name: " + this.givenName
                + "\n   >> User.User ID: " + this.userId
                + "\n   >> Phone Number: " + this.phoneNumber;
    }

    public void display() {
        ct.printBox("   >> Family name: " + this.familyName,
                "   >> Given name: " + this.givenName,
                "   >> User.User ID: " + this.userId,
                "   >> Phone Number: " + this.phoneNumber);
    }

    public Account getUserAcc() {
        return userAcc;
    }

    public String getUserId() {
        return userId;
    }

    public String getFamilyName() {
        return familyName;
    }

    public String getGivenName() {
        return givenName;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void viewActiveBookings(){
        this.getUserAcc().getBookings(true);
    }

    public void viewBookings(){
        this.getUserAcc().getBookings(false);
    }

    public void chooseSitePrompt(){
        ct.printBox("(!) Please search and identify a Testing Site before making a Booking!",
                "Ensure that you record the Testing Site ID!");
        this.viewAndSearchTestingSites();
    }

    public void chooseBookingPrompt(){
        ct.printBox("(!) Please search and identify a Booking to modify.",
                "Ensure that you record the Booking ID!");
        this.getUserAcc().getBookings(true);
    }

    /**
     * Creates ON-SITE Testing,
     * Retrieves booking information upon confirmation
     * function, which users search for testing sites, retrieve ID and makes a
     * booking.
     */
    public void createOnSiteTestingBooking() {
        String siteId;
        this.chooseSitePrompt();
        input = new Scanner(System.in);
        System.out.print("Please enter a valid testing site ID: ");
        siteId = input.nextLine();
        SiteSearchFacade siteSearchFacade = new SiteSearchFacade();

        HttpResponse<String> response = api.getRequest("/testing-site/" + siteId);
        if(response.statusCode() == 200 && siteSearchFacade.identifyAvailability(siteId)) {
            OnSiteTestingBooking booking = new OnSiteTestingBooking(this, siteId);
            bookingFacade = new BookingFacade();
            boolean verifyBooking = bookingFacade.registerOnSiteBooking(this, booking);
            booking.extractPinCode();
            response(verifyBooking, booking);
        } else if (!(response.statusCode() == 200)) {
            ct.printBox("(!) Invalid Testing Site ID, Please re-verify again.");
        } else{
            ct.printBox("(!) The Testing Site is Currently Out of Service",
                    "Please make a booking at another time.");
        }
    }

    /**
     * Creates HOME Testing,
     * Retrieves booking information upon confirmation
     * function, which users search for testing sites, retrieve ID and makes a
     * booking.
     */
    public void createHomeTestingBooking() {
        String siteId;
        this.chooseSitePrompt();
        input = new Scanner(System.in);
        System.out.print("Please enter a valid testing site ID: ");
        siteId = input.nextLine();

        SiteSearchFacade siteSearchFacade = new SiteSearchFacade();
        HttpResponse<String> response = api.getRequest("/testing-site/" + siteId);
        if (response.statusCode() == 200 && siteSearchFacade.identifyAvailability(siteId)) {
            HomeTestingBooking booking = new HomeTestingBooking(this, siteId);
            bookingFacade = new BookingFacade();
            booking.requireRatPrompt();
            response(bookingFacade.registerHomeBooking(this, booking), booking);
        } else if (!(response.statusCode() == 200)) {
            ct.printBox("(!) Invalid Testing Site ID, Please re-verify again.");
        } else{
            ct.printBox("(!) The Testing Site is Currently Out of Service",
                    "Please make a booking at another time.");
        }
    }

    /**
     * Displays booking modifications
     * @see BookingFacade
     */
    public boolean displayBookingModifications(String identifier){
        return bookingFacade.displayBookingModifications(identifier);
    }

    /**
     * Reverts a booking modification
     * @see DefaultInterface
     */
    public void revertModification(String uId, int selection){
        userInterface.revertModification(uId, selection);
    }

    /**
     * Modify a booking time
     * @see DefaultInterface
     */
    public void modifyBookingTime(String bookingId, boolean isRevert, int selection){
        userInterface.modifyBookingTime(bookingId, isRevert, selection);
    }

    /**
     * Modify a booking venue
     * @see DefaultInterface
     */
    public void modifyBookingVenue(String bookingId, String newVenue, boolean isRevert, int selection){
        userInterface.modifyBookingVenue(bookingId, newVenue, isRevert, selection);
    }

    /**
     * Cancels a booking based on Booking ID
     * @see DefaultInterface
     */
    public void cancelBooking(String bookingId){
        userInterface.cancelBooking(bookingId);
    }

    /**
     * Displays booking prompt for GUI
     * 
     * @param isSuccessful condition whether the booking was successful
     * @param booking      the booking object
     */
    public void response(boolean isSuccessful, Booking booking) {
        if (isSuccessful) {
            booking.bookingSuccessful();
        } else {
            booking.bookingFailure();
        }
    }

    public void viewAndSearchTestingSites(){
        SiteSearchFacade site = new SiteSearchFacade();
        site.searchSitePrompt();
    }

    /**
     * Prompt for GUI-based implementation
     */
    @Override
    public void prompt() {
        ct.printBox("Hello "
                + this.userAcc.getRole()
                + ": "
                + getGivenName()
                + getFamilyName()
                + "!",
                "What would you like to do today?");
    }

    /**
     * Display options that a user has, GUI-based implementation
     */
    @Override
    public void displayOptions() {
    }

    /**
     * Displays the menu that is unique for each user, GUI-based implementation
     * 
     * @throws IOException IOException
     */
    @Override
    public void menu() throws IOException {
    }
    
}
