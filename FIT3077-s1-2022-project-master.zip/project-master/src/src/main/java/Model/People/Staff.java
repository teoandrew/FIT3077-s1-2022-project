package Model.People;

/**
 * Abstract class for Staff
 */
public abstract class Staff extends User{

    public Staff(String newFamName, String newGivName, String newUId, String newPhoneNum, UserType newUType){
        super(newFamName, newGivName, newUId, newPhoneNum, newUType);
    }

}
