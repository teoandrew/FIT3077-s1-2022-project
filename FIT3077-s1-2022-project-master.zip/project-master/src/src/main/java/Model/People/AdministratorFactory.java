package Model.People;

/**
 * Abstract factory class for administrator
 */
public class AdministratorFactory implements UserAbstractFactory {

    private String familyName;
    private String givenName;
    private String userId;
    private String phoneNumber;

    public AdministratorFactory(String newFamilyName, String newGivenName, String newUserId, String newPhoneNumber){
        this.familyName = newFamilyName;
        this.givenName = newGivenName;
        this.userId = newUserId;
        this.phoneNumber = newPhoneNumber;
    }

    @Override
    public User createUser() {
        return new Administrator(familyName, givenName, userId, phoneNumber);
    }
}
