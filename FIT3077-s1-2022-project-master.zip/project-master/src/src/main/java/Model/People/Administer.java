package Model.People;
import Main.Application;
import java.util.*;
import API.CovidTestFacade;
import API.SiteSearchFacade;

/**
 * Administer class
 */
public class Administer extends Staff {

    public Administer(String newFamName, String newGivName, String newUId, String newPhoneNum){
        super(newFamName, newGivName, newUId, newPhoneNum, UserType.Administer);
    }

    public String toString(){
        return "(!) Administer details: \n" + super.toString();
    }

    @Override
    public String viewAccountDetails() {
        return this.toString();
    }


    public void createTest(){
        String pId, bId;
        input = new Scanner(System.in);

        // Input Prompt
        ct.printBox("(!) Creating a COVID Test!");
        System.out.print(">> Please input patient user ID: ");
        pId = input.nextLine();
        System.out.print(">> Please input booking ID: ");
        bId = input.nextLine();

        CovidTestFacade covidTestFacade = new CovidTestFacade();
        covidTestFacade.create(pId, bId, this.getUserId());
    }

    public void updateTest(){
        String tId;
        input = new Scanner(System.in);
        // Input Prompt
        ct.printBox("(!) Updating Test Results",
                "NOTE: Ensure a COVID Test is completed prior to this operation!");
        System.out.print(">> Please enter COVID-Test ID: ");
        tId = input.nextLine();

        // Getting the test object
        CovidTestFacade covidTestFacade = new CovidTestFacade();
        covidTestFacade.update(tId);
    }


    @Override
    public void displayOptions(){
        ct.printBox("Options Available: ",
                "(1) Make a System Booking",
                "(2) Make a Home Booking",
                "(3) Search and View Testing Sites",
                "(4) View User Account Details",
                "(5) View Bookings Made",
                "(6) View Active Bookings",
                "(7) Modify an Existing Booking",
                "(8) Revert a Modification",
                "(9) Create a Test",
                "(10) Update Test Details",
                "(11) Log Out");
    }

    @Override
    public void menu(){
        String res;
        boolean exit = false;
        this.prompt();
        input = new Scanner(System.in);
        while (!exit) {
            this.displayOptions();
            System.out.print(">> Please pick an option: ");
            res = input.nextLine();
            switch (res) {
                case "1" -> this.createOnSiteTestingBooking();
                case "2" -> this.createHomeTestingBooking();
                case "3" -> {
                    SiteSearchFacade site = new SiteSearchFacade();
                    site.searchSitePrompt();
                }
                case "4" -> this.display();
                case "5" -> this.viewBookings();
                case "6" -> this.viewActiveBookings();
                case "7" -> {
                    boolean exit2 = false;
                    while (!exit2) {
                        ct.printBox("Options Available: ",
                                "(1) Modify Booking Venue",
                                "(2) Modify Booking Time",
                                "(3) Cancel Booking",
                                "(4) Quit View OR Modification");
                        System.out.print(">> Please pick an option: ");
                        res = input.nextLine();
                        switch (res){
                            case "1" -> {
                                String bId, tId;
                                ct.printBox("(!) Modify Booking Venue", "If you have a PIN, please exit and obtain the Booking ID first!");
                                System.out.print(">> Please enter Booking ID: ");
                                bId = input.nextLine();
                                System.out.print(">> Please enter Site ID (to-be changed into): ");
                                tId = input.nextLine();
                                this.modifyBookingVenue(bId, tId, false, -1);
                            }
                            case "2" -> {
                                String bId;
                                ct.printBox("(!) Modify Booking Time", "If you have a PIN, please exit and obtain the ID first!");
                                System.out.print(">> Please enter Booking ID: ");
                                bId = input.nextLine();
                                this.modifyBookingTime(bId, false, -1);
                            }
                            case "3" -> {
                                String bId;
                                ct.printBox("(!) Cancel A Booking", "If you have a PIN, please exit and obtain the Booking ID first!");
                                System.out.print(">> Please enter Booking ID: ");
                                bId = input.nextLine();
                                this.cancelBooking(bId);
                            }
                            case "4" -> exit2 = true;
                        }
                    }
                }
                case "8" -> {
                    boolean cond = true;
                    while (cond) {
                        int selection;
                        ct.printBox("(!) Reverting a Modification");
                        cond = this.displayBookingModifications(this.getUserId());
                        if (cond) {
                            System.out.print(">> Please enter a modification to be reverted: ");
                            selection = Integer.parseInt(input.nextLine());
                            if (selection >= 1 && selection <= 3) {
                                this.revertModification(this.getUserId(), selection);
                                cond = false;
                            } else {
                                ct.printBox("(!) Please input a valid number.");
                            }
                        }
                    }
                }
                case "9" -> this.createTest();
                case "10" -> this.updateTest();
                case "11" -> {
                    exit = true;
                    Application.getInstance().displayMenu();
                }
                default -> System.out.println("Invalid Input");
            }
        }
    }

}
