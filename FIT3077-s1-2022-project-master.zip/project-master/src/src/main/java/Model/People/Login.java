package Model.People;

import View.ConsoleText;

import org.json.JSONObject;

import API.API;

import java.io.IOException;
import java.net.http.HttpResponse;
import java.util.Base64;

/**
 * Login class
 */
public class Login {

    // Stored attributes
    private final String username;
    private final String password;
    // GUI Related Components
    private final ConsoleText ct = new ConsoleText();
    protected API api = API.getInstance();

    /**
     * Default login Constructor
     * @param userName user's login username
     * @param passWord user's login password
     */
    public Login(String userName, String passWord){
        username = userName;
        password = passWord;
    }

    /**
     * Authenticates the given credentials and initiates user menu
     * @throws RuntimeException
     * @throws IOException
     */
    public boolean authenticate() throws RuntimeException, IOException {
        String credentials = new JSONObject()
                .put("userName", username)
                .put("password", password)
                .toString();

        HttpResponse<String> response = api.postRequest(credentials, "/user/login?jwt=true");
        if(statusVerifier(response.statusCode())){
            String token = new JSONObject(response.body())
                    .getString("jwt");
            User user = extractRole(decodeJWT(token));
            user.menu();
            return true;
        }
        return false;
    }

    /**
     * GUI related method, displays the information based on status code
     * @param statusCode statusCode returned by the web service
     * @return boolean true if login was successful, false otherwise.
     */
    public boolean statusVerifier(int statusCode){
        if (statusCode == 200){
            ct.printBox("(!) Login successful!");
            return true;
        } else if (statusCode == 403){
            ct.printBox("(!) Login unsuccessful and due to:",
                    "Invalid username",
                    "OR",
                    "Invalid password");
            return false;
        } else if (statusCode == 401) {
            ct.printBox("(!) Internal API error!");
            return false;
        } else {
            ct.printBox("(!) Parsing error!");
            return false;
        }
    }

    /**
     * Decodes a JWT Token
     * @param jwtToken token provided by web service
     * @return String containing details of the user
     */
    public String decodeJWT(String jwtToken){
        // Decoding JWT
        String[] split_string = jwtToken.split("\\.");
        String base64EncodedBody = split_string[1];
        // JWT Body
        return new String(Base64.getDecoder().decode(base64EncodedBody));
    }

    /**
     * Extract the user's role to initiate its menu
     * @param jwtString decoded String containing details of the user
     * @return a User.User, representing its role in the system.
     */
    public User extractRole(String jwtString){
        JSONObject obj = new JSONObject(jwtString);

        String userId      = obj.getString("sub");
        String familyName  = obj.getString("familyName");
        String givenName   = obj.getString("givenName");
        String phoneNumber = obj.getString("phoneNumber");

        if (obj.getBoolean("isCustomer")){
            return UserFactory.getUser(new CustomerFactory(familyName, givenName, userId, phoneNumber));
        } else if (obj.getBoolean("isHealthcareWorker")){
            return UserFactory.getUser(new AdministerFactory(familyName, givenName, userId, phoneNumber));
        } else {
            return UserFactory.getUser(new AdministratorFactory(familyName, givenName, userId, phoneNumber));
        }
    }
}
