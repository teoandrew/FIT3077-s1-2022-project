package Model.People;

/**
 * Abstract factory class for administer
 */
public class AdministerFactory implements UserAbstractFactory {


    private String familyName;
    private String givenName;
    private String userId;
    private String phoneNumber;

    public AdministerFactory(String newFamilyName, String newGivenName, String newUserId, String newPhoneNumber){
        this.familyName = newFamilyName;
        this.givenName = newGivenName;
        this.userId = newUserId;
        this.phoneNumber = newPhoneNumber;
    }

    @Override
    public User createUser() {
        return new Administer(familyName, givenName, userId, phoneNumber);
    }

}
