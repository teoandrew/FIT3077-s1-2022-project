package Model.TestingSite;

/**
 * Testing site class
 */
public class TestingSite {

    private String siteId;
    private String siteName;
    private Address siteAddress;
    private boolean isDriveThrough;
    private boolean isWalkIn;
    private boolean isClinic;
    private boolean isGP;
    private boolean isHospital;
    
    public TestingSite(String siteId, String siteName, Address siteAddress, boolean isDriveThrough, boolean isWalkIn, boolean isClinic, boolean isGP, boolean isHospital) {
        this.siteId = siteId;
        this.siteName = siteName;
        this.siteAddress = siteAddress;
        this.isDriveThrough = isDriveThrough;
        this.isWalkIn = isWalkIn;
        this.isClinic = isClinic;
        this.isGP = isGP;
        this.isHospital = isHospital;
    }

    public TestingSite(){
    }

    public String getSiteId() {
        return this.siteId;
    }

    public String getSiteName() {
        return this.siteName;
    }

    public Address getSiteAddress() {
        return this.siteAddress;
    }

    public boolean getIsDriveThrough() {
        return this.isDriveThrough;
    }

    public void setIsDriveThrough(boolean isDriveThrough) {
        this.isDriveThrough = isDriveThrough;
    }

    public boolean getIsWalkIn() {
        return this.isWalkIn;
    }

    public void setIsWalkIn(boolean isWalkIn) {
        this.isWalkIn = isWalkIn;
    }

    public boolean getIsClinic() {
        return this.isClinic;
    }

    public void setIsClinic(boolean isClinic) {
        this.isClinic = isClinic;
    }

    public boolean getIsGP() {
        return this.isGP;
    }

    public void setIsGP(boolean isGP) {
        this.isGP = isGP;
    }

    public boolean getIsHospital() {
        return this.isHospital;
    }

    public void setIsHospital(boolean isHospital) {
        this.isHospital = isHospital;
    }

    @Override
    public String toString() {
        return "{" +
            " siteId='" + getSiteId() + "'" +
            ", siteName='" + getSiteName() + "'" +
            ", siteAddress='" + getSiteAddress() + "'" +
            "}";
    }

    public void setSiteId(String siteId) {
        this.siteId = siteId;
    }

    public void setSiteName(String siteName) {
        this.siteName = siteName;
    }

    public void setSiteAddress(Address siteAddress) {
        this.siteAddress = siteAddress;
    }
}
