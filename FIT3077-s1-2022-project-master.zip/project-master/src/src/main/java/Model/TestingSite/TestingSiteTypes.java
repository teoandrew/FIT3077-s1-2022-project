package Model.TestingSite;

/**
 * Types of testing sites
 */
public enum TestingSiteTypes {
    DriveThrough,
    WalkIn,
    Clinic,
    GP,
    Hospital,
}