package Model.TestingSite;

/**
*  This is a collection class for storing the address of a TestingSite.TestingSite
*/ 
public class Address {

    private final int latitude;
    private final int longitude;
    private final String unitNumber;
    private final String street;
    private final String street2;
    private final String suburb;
    private final String state;
    private final String postcode;

    public Address(int latitude, int longitude, String unitNumber, String street, String street2, String suburb, String state, String postcode) {
        this.latitude = latitude;
        this.longitude = longitude;
        this.unitNumber = unitNumber;
        this.street = street;
        this.street2 = street2;
        this.suburb = suburb;
        this.state = state;
        this.postcode = postcode;
    }    

    public int getLatitude() {
        return this.latitude;
    }


    public int getLongitude() {
        return this.longitude;
    }


    public String getUnitNumber() {
        return this.unitNumber;
    }


    public String getStreet() {
        return this.street;
    }


    public String getStreet2() {
        return this.street2;
    }


    public String getSuburb() {
        return this.suburb;
    }


    public String getState() {
        return this.state;
    }


    public String getPostcode() {
        return this.postcode;
    }

    @Override
    public String toString() {
        return "{" +
            " latitude='" + getLatitude() + "'" +
            ", longitude='" + getLongitude() + "'" +
            ", unitNumber='" + getUnitNumber() + "'" +
            ", street='" + getStreet() + "'" +
            ", street2='" + getStreet2() + "'" +
            ", suburb='" + getSuburb() + "'" +
            ", state='" + getState() + "'" +
            ", postcode='" + getPostcode() + "'" +
            "}";
    }
}
