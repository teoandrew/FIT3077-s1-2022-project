package Model.Booking;

/**
 * Statuses of booking used in the booking process
 */
public enum BookingStatus {
    INITIATED,
    VERIFIED,
    COMPLETED,
    CANCELLED,
    ELAPSED
}
