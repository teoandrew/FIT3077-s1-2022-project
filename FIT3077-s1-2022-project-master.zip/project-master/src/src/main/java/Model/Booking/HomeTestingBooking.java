package Model.Booking;

import Model.People.User;

import java.util.Random;
import java.util.Scanner;

/** 
 * Booking.HomeTestingBooking class
 */
public class HomeTestingBooking extends Booking {

    private String siteURL;
    private String qrCode = "N/A if RAT kits are not required.";
    private boolean requireRAT;

    public HomeTestingBooking(User customer, String testingSiteId) {
        super(customer, testingSiteId);
        this.setBookingType(BookingType.HOME);
    }

    @Override
    public String toString(){
        return "(!) Booking.Booking Information: "
                + "\n Booking Type: HOME-TESTING"
                + "\n Booking ID: "       + this.getBookingId()
                + "\n Booking User.User: \n"   + this.getCustomer().toString()
                + "\n Require RAT Kits: " + this.requireRAT
                + "\n Booking QR: "       + this.getQrCode()
                + "\n Booking URL: "      + this.getSiteURL()
                + "\n Booking Site: "     + this.getTestingSiteId();
    }

    @Override
    public void display(){
        ct.printBox("(!) Booking.Booking Information:",
                "Booking Type: HOME-TESTING",
                "Booking ID: "       + this.getBookingId(),
                "Booking User: ",
                this.getCustomer().toString(),
                "Require RAT Kits: " + this.requireRAT,
                "Booking QR: "       + this.getQrCode(),
                "Booking URL: "      + this.getSiteURL(),
                "Booking Site: "     + this.getTestingSiteId());
    }

    public void setSiteURL(String siteURL) {
        this.siteURL = siteURL;
    }

    public String getSiteURL() {
        return siteURL;
    }

    public void setQrCode(String qrCode) {
        this.qrCode = qrCode;
    }

    public String getQrCode() {
        return qrCode;
    }

    public boolean getRequireRAT(){
        return this.requireRAT;
    }

    /**
     * Shows a prompt to check whether the user requires RAT Kits.
     * Always generate a SiteURL regardless!
     * Generates QR Code only if the user requires RAT Kits
     */
    public void requireRatPrompt(){
        this.generateSiteURL();

        Scanner input = new Scanner(System.in);
        boolean condition = false;
        while (!condition) {
            ct.printBox("Would you require RAT kits for Home Testing?",
                    "(1) YES (self-collect at a testing site)",
                    "(2) NO  (do not require self-collect)");
            System.out.print(">> Please input an option: ");
            String option = input.nextLine();
            switch (option){
                case "1" -> {
                    this.requireRAT = true;
                    this.generateQrCode();
                    condition = true;
                }
                case "2" -> {
                    this.requireRAT = false;
                    condition = true;
                }
                default -> ct.printBox("Invalid option! Please input a valid option.");
            }
        }

    }

    /**
     * Random String Generator for the time-being
     * @return a random String
     */
    protected String getRandomString() {
        String AVAILABLECHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
        StringBuilder str = new StringBuilder();
        Random rnd = new Random();
        while (str.length() < 18) { // length of the random string.
            int index = (int) (rnd.nextFloat() * AVAILABLECHARS.length());
            str.append(AVAILABLECHARS.charAt(index));
        }
        return str.toString();
    }

    /**
     * Generates a random QR Code
     */
    public void generateQrCode(){
        String randStr = this.getRandomString();
        this.setQrCode(randStr);
    }

    /**
     * Generates a random Zoom Link as Site URL
     */
    public void generateSiteURL(){
        String siteBaseURL = "https://monash.zoom.us/j/";
        String randStr = this.getRandomString();
        this.setSiteURL(siteBaseURL + randStr);
    }
}
