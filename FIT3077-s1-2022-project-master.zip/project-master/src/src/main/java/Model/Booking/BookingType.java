package Model.Booking;

/**
 * Type of booking
 */
public enum BookingType {
    ON_SITE,
    HOME
}
