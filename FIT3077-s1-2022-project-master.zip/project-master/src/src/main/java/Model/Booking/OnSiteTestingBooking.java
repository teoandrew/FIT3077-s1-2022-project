package Model.Booking;

import Model.People.User;

import org.json.JSONObject;

import java.net.http.HttpResponse;

/**
 * Booking.OnSiteTestingBooking class
 */
public class OnSiteTestingBooking extends Booking {

    private String pinCode;

    public OnSiteTestingBooking(User customer, String testingSiteId) {
        super(customer, testingSiteId);
        this.setBookingType(BookingType.ON_SITE);
    }

    public OnSiteTestingBooking(){}

    public String toString(){
        return "(!) Booking Information: "
                + "\n Booking Type: ON-SITE"
                + "\n Booking ID: " + this.getBookingId()
                + "\n Booking User.User: \n" + this.getCustomer().toString()
                + "\n Booking SMS PIN: " + this.getPinCode()
                + "\n Booking Site: " + this.getTestingSiteId();
    }

    public void display(){
        ct.printBox("(!) Booking Information:",
                "Booking Type: ON-SITE",
                "Booking ID: " + this.getBookingId(),
                "Booking User: ",
                this.getCustomer().toString(),
                "Booking SMS PIN: " + this.getPinCode(),
                "Booking Site: " + this.getTestingSiteId());
    }

    /**
     * Extracts PIN Code from a booking, based on the ID
     * NOTE: Requires Booking.Booking Object to be instantiated!
     */
    public void extractPinCode(){
        HttpResponse<String> response = api.getRequest("/booking/" + this.getBookingId());
        JSONObject json = new JSONObject(response.body());
        this.setPinCode(json.getString("smsPin"));
    }

    public void setPinCode(String pinCode) {
        this.pinCode = pinCode;
    }

    public String getPinCode() {
        return pinCode;
    }
}
