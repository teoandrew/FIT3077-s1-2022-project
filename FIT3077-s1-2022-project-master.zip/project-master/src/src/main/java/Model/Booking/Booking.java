package Model.Booking;

import Model.People.User;
import View.ConsoleText;

import API.API;

/**
 * Booking class
 */
public class Booking{

    private String testingSiteId;
    private User customer;
    private String bookingId;
    private String creationTime;
    private String updatedTime;
    private BookingStatus status;
    private BookingType bookingType;

    public static int changeHistoryNo;  // for keeping track of Booking change history

    protected API api = API.getInstance();
    protected ConsoleText ct = new ConsoleText();

    public Booking (User customer, String testingSiteId){
        this.customer = customer;
        this.testingSiteId = testingSiteId;
    }

    public Booking(){}

    public String toString(){
        return null;
    }
    public void display(){}

    public void bookingSuccessful(){
        ct.printBox("(!) Your booking has been successfully initiated.");
        this.display();
    }

    public void bookingFailure(){
        ct.printBox("(!) Unfortunately we we're unable to process your booking.",
                "Please retry again!");
    }

    public void setBookingType(BookingType bookingType) {
        this.bookingType = bookingType;
    }

    public void setBookingId(String bookingId){
        this.bookingId = bookingId;
    }

    public void setStatus(BookingStatus status){
        this.status = status;
    }

    public String getBookingId(){
        return this.bookingId;
    }

    public BookingStatus getStatus() {
        return this.status;
    }

    public String getCreationTime() {
        return creationTime;
    }

    public String getUpdatedTime() {
        return updatedTime;
    }

    public BookingType getBookingType() {
        return bookingType;
    }

    public void setCreationTime(String creationTime) {
        this.creationTime = creationTime;
    }

    public void setUpdatedTime(String updatedTime) {
        this.updatedTime = updatedTime;
    }

    public User getCustomer() {
        return customer;
    }

    public String getTestingSiteId() {
        return testingSiteId;
    }

    public int getChangeHistoryNo() {
        return changeHistoryNo;
    }

    public int setChangeHistoryNo() {
        if (Booking.changeHistoryNo < 3) {
            Booking.changeHistoryNo += 1;
        } else if (Booking.changeHistoryNo == 3) {
            Booking.changeHistoryNo = 1;
        }
        return Booking.changeHistoryNo;
    }
}
