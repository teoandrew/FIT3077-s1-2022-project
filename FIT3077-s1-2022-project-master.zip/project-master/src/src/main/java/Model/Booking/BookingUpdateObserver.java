package Model.Booking;

import View.ConsoleText;
import org.json.JSONArray;

import java.net.http.HttpResponse;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.temporal.ChronoUnit;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

import static API.API.api;

public class BookingUpdateObserver {

    protected ConsoleText ct = new ConsoleText();
    private final String facilityId;
    private Map<LocalDateTime, String> newBookings;
    private Map<LocalDateTime, String> newModifications;
    private Map<LocalDateTime, String> newDeletions;
    private Map<LocalDateTime, String> newReverts;

    public BookingUpdateObserver(String fId){
        this.facilityId         = fId;
        this.newBookings        = new HashMap<>();
        this.newModifications   = new HashMap<>();
        this.newDeletions       = new HashMap<>();
        this.newReverts         = new HashMap<>();
    }

    public Map<LocalDateTime, String> getSortedBookings() {
        return new TreeMap<>(newBookings);
    }

    public Map<LocalDateTime, String> getSortedModifications() {
        return new TreeMap<>(newModifications);
    }

    public Map<LocalDateTime, String> getSortedDeletions() {
        return new TreeMap<>(newDeletions);
    }

    public Map<LocalDateTime, String> getSortedReverts() {
        return new TreeMap<>(newReverts);
    }


    public void update(){
        this.updateForNewBookings(this.facilityId);
        this.updateForModificationsDeletionsOrReverts(this.facilityId);
    }

    /**
     * Checks for new booking creations in a particular facility
     * NOTE: restricted to recent updates, i.e., modifications made within that day
     * @param fId string, facility ID
     */
    public void updateForNewBookings(String fId){
        // Check for new booking creations
        Instant currentTime = Instant.now();
        Instant timeLowerBound = currentTime.truncatedTo(ChronoUnit.DAYS);
        Instant timeUpperBound = currentTime.plus(1, ChronoUnit.DAYS).truncatedTo(ChronoUnit.DAYS);
        HttpResponse<String> getBookings = api.getRequest("/booking");
        JSONArray bookings = new JSONArray(getBookings.body());
        for (int i = 0; i < bookings.length(); i++){
            if(bookings.getJSONObject(i).getJSONObject("testingSite").getString("id").equals(fId)){
                LocalDateTime ldt = LocalDateTime.parse(bookings.getJSONObject(i).getString("createdAt").replaceAll("Z", ""));
                Instant instant = ldt.toInstant(ZoneOffset.ofHours(0));
                if(instant.compareTo(timeLowerBound) > 0 && instant.compareTo(timeUpperBound) < 0) {
                    newBookings.put(ldt, bookings.getJSONObject(i).getString("id").replaceAll("\"", ""));
                }
            }
        }
    }

    /**
     * Checks for booking modifications, deletions and reverts in a particular facility
     * NOTE: restricted to recent updates, i.e., modifications made within that day
     * @param fId string, facility ID
     */
    public void updateForModificationsDeletionsOrReverts(String fId) {
        Instant currentTime = Instant.now();
        Instant timeLowerBound = currentTime.truncatedTo(ChronoUnit.DAYS);
        Instant timeUpperBound = currentTime.plus(1, ChronoUnit.DAYS).truncatedTo(ChronoUnit.DAYS);
        HttpResponse<String> getUsers = api.getRequest("/user");
        JSONArray users = new JSONArray(getUsers.body());
        // Check for any kind of modifications 
        for (int i = 0; i < users.length(); i++) {
            // Check for Modifications
            if (!users.getJSONObject(i).getJSONObject("additionalInfo").isNull("modifications")) {
                JSONArray modifications = new JSONArray(users.getJSONObject(i).getJSONObject("additionalInfo").getJSONArray("modifications"));
                this.checkForModifications(modifications, timeLowerBound, timeUpperBound, fId);
            }
            // Check for Deletions
            if (!users.getJSONObject(i).getJSONObject("additionalInfo").isNull("deletedBookings")) {
                JSONArray deletions = new JSONArray(users.getJSONObject(i).getJSONObject("additionalInfo").getJSONArray("deletedBookings"));
                this.checkForDeletions(deletions, timeLowerBound, timeUpperBound, fId);
            }
            // Check for Reverts
            if (!users.getJSONObject(i).getJSONObject("additionalInfo").isNull("reverted")) {
                JSONArray reverts = new JSONArray(users.getJSONObject(i).getJSONObject("additionalInfo").getJSONArray("reverted"));
                this.checkForReverts(reverts, timeLowerBound, timeUpperBound, fId);
            }
        }
    }

    /**
     * Helper function for updateForModificationsDeletionsOrReverts()
     * 
     * Checks for modifications in the additionalInfo field for a given user
     * 
     * @param modifications JSONArray, values in the modifications field in the JSON database 
     * @param timeLowerBound Instant, lower bound of current time
     * @param timeUpperBound Instant, upper bound of current time
     */
    public void checkForModifications(JSONArray modifications, Instant timeLowerBound, Instant timeUpperBound, String fId){
        for (int j = 0; j < modifications.length(); j++) {
            LocalDateTime ldt = LocalDateTime.parse(modifications.getJSONObject(j).getString("dateModified").replaceAll("Z", ""));
            Instant instant = ldt.toInstant(ZoneOffset.ofHours(0));
            if (instant.compareTo(timeLowerBound) > 0 && instant.compareTo(timeUpperBound) < 0 && (modifications.getJSONObject(j).getString("facilityId").equals(fId)) || modifications.getJSONObject(j).getString("initialValue").equals(fId)) {
                String bId, type, initialValue, combinedStr, newValue;
                bId = modifications.getJSONObject(j).getString("bookingId");
                type = modifications.getJSONObject(j).getString("type");
                newValue = modifications.getJSONObject(j).getString("newValue");
                initialValue = modifications.getJSONObject(j).getString("initialValue");
                combinedStr = "Modified Booking ID: " + bId + " || Modification Type: " + type + " || Modification Initial Value: " + initialValue + " || Modification New Value: " + newValue;
                newModifications.put(ldt, combinedStr);
            }
        }
    }

    /**
     * Helper function for updateForModificationsDeletionsOrReverts()
     * 
     * Checks for deletions in the additionalInfo field for a given user
     * 
     * @param modifications JSONArray, values in the deletions field in the JSON database 
     * @param timeLowerBound Instant, lower bound of current time
     * @param timeUpperBound Instant, upper bound of current time
     */
    public void checkForDeletions(JSONArray deletions, Instant timeLowerBound, Instant timeUpperBound, String fId){
        for (int k = 0; k < deletions.length(); k++) {
            LocalDateTime ldt = LocalDateTime.parse(deletions.getJSONObject(k).getString("dateDeleted").replaceAll("Z", ""));
            Instant instant = ldt.toInstant(ZoneOffset.ofHours(0));
            if (instant.compareTo(timeLowerBound) > 0 && instant.compareTo(timeUpperBound) < 0 && deletions.getJSONObject(k).getString("facilityId").equals(fId)) {
                String bId2, combinedStr2;
                bId2 = deletions.getJSONObject(k).getString("bookingId");
                combinedStr2 = "Booking Deletion ID: " + bId2;
                newDeletions.put(ldt, combinedStr2);
            }
        }
    }

    /**
     * Helper function for updateForModificationsDeletionsOrReverts()
     * 
     * Checks for deletions in the additionalInfo field for a given user
     * 
     * @param modifications JSONArray, values in the deletions field in the JSON database 
     * @param timeLowerBound Instant, lower bound of current time
     * @param timeUpperBound Instant, upper bound of current time
     */
    public void checkForReverts(JSONArray reverts, Instant timeLowerBound, Instant timeUpperBound, String fId){
        for (int k = 0; k < reverts.length(); k++) {
            LocalDateTime ldt = LocalDateTime.parse(reverts.getJSONObject(k).getString("dateModified").replaceAll("Z", ""));
            Instant instant = ldt.toInstant(ZoneOffset.ofHours(0));
            if (instant.compareTo(timeLowerBound) > 0 && instant.compareTo(timeUpperBound) < 0 && (reverts.getJSONObject(k).getString("facilityId").equals(fId) || reverts.getJSONObject(k).getString("to").equals(fId))) {
                String bId3, from, to, type, combinedStr3;
                bId3 = reverts.getJSONObject(k).getString("bookingId");
                from = reverts.getJSONObject(k).getString("from");
                to = reverts.getJSONObject(k).getString("to");
                type = reverts.getJSONObject(k).getString("mType");
                combinedStr3 = "Booking Reverted ID: " + bId3 + " || Reversion Type: " + type + " || From: " + from + " || To: " + to;
                newReverts.put(ldt, combinedStr3);
            }
        }
    }
}
