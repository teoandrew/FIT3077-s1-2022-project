package Model.CovidTesting;

/**
 * Status of Covid-19 tests
 */
public enum TestStatus {
    INITIATED,
    REATTEMPT,
    COMPLETED
}
