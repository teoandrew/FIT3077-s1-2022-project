package Model.CovidTesting;

/**
 * Types of Covid-19 test
 */
public enum TestType {
    PCR,
    RAT
}
