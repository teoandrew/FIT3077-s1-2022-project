package Model.CovidTesting;

/**
 * Possible Covid-19 test results
 */
public enum TestResults {
    POSITIVE,
    NEGATIVE,
    INVALID,
    PENDING
}
