package Model.CovidTesting;

import API.API;
import Model.People.User;
import View.ConsoleText;

/**
 * Covid test class
 */
public class CovidTest{
    protected ConsoleText ct = new ConsoleText();
    private String testId;
    private String bookingId;
    private User patient;
    private String dateAndTimePerformed;
    private String dateAndTimeOfResults = "N/A";
    private TestType testType;
    private String administerId;
    private TestStatus status;
    private String dateAndTimeOfUpdate;
    private TestResults testResult;
    protected API api = API.getInstance();

    public CovidTest(User patient, String bookingId){
        this.patient = patient;
        this.bookingId = bookingId;
    }

    public CovidTest(){}

    public String toString(){
        return "";
    }

    public void setTestId(String testId) {
        this.testId = testId;
    }

    public String getTestId() {
        return testId;
    }

    public void testCreationSuccessful(){
        ct.printBox("Test Created Successfully!");
        this.display();
    }

    public void testCreationFailure(){
        ct.printBox("Test Creation Failed! Please re-try again!");
    }

    public void display(){
        ct.printBox("(!) Test Confirmation Information",
                "Test ID: " + this.getTestId(),
                "Test Type: " + this.getTestType(),
                "Test Patient Info:",
                ">> Patient ID: " + this.getPatient().getUserId(),
                ">> Patient Name: " + this.getPatient().getFamilyName() + this.getPatient().getGivenName(),
                ">> Patient Phone: " + this.getPatient().getPhoneNumber(),
                "Test Booking ID: " + this.getBookingId(),
                "Test Status: " + this.getStatus(),
                "Test Date Performed: " + this.getDateAndTimePerformed(),
                "Test Results: " + this.getTestResult());
    }

    public User getPatient() {
        return patient;
    }

    public void setTestResult(TestResults testResult) {
        this.testResult = testResult;
    }

    public TestResults getTestResult() {
        return testResult;
    }

    public void setAdministerId(String administerId) {
        this.administerId = administerId;
    }

    public void setDateAndTimeOfResults(String dateAndTimeOfResults) {
        this.dateAndTimeOfResults = dateAndTimeOfResults;
    }

    public void setDateAndTimeOfUpdate(String dateAndTimeOfUpdate) {
        this.dateAndTimeOfUpdate = dateAndTimeOfUpdate;
    }

    public void setDateAndTimePerformed(String dateAndTimePerformed) {
        this.dateAndTimePerformed = dateAndTimePerformed;
    }

    public void setStatus(TestStatus status) {
        this.status = status;
    }

    public void setTestType(TestType testType) {
        this.testType = testType;
    }

    public String getAdministerId() {
        return administerId;
    }

    public String getBookingId() {
        return bookingId;
    }

    public String getDateAndTimeOfResults() {
        return dateAndTimeOfResults;
    }

    public String getDateAndTimeOfUpdate() {
        return dateAndTimeOfUpdate;
    }

    public String getDateAndTimePerformed() {
        return dateAndTimePerformed;
    }

    public TestStatus getStatus() {
        return status;
    }

    public TestType getTestType() {
        return testType;
    }

    public void setBookingId(String bookingId) {
        this.bookingId = bookingId;
    }

    public void setPatient(User patient) {
        this.patient = patient;
    }
}
