package API;

/**
 * Search interface
 */
public interface SearchInterface {

    default void search(String identifier, boolean displayView){}

}
