package API;

import Model.CovidTesting.CovidTest;
import Model.CovidTesting.TestResults;
import Model.CovidTesting.TestStatus;
import Model.CovidTesting.TestType;
import Model.People.PatientFactory;
import Model.People.User;
import Model.People.UserFactory;
import View.ConsoleText;
import View.CovidTestView;

import org.json.JSONObject;

import Controller.CovidTestController;

import java.net.http.HttpResponse;
import java.time.Instant;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;

/**
 * Facade class for CovidTest
 */
public class CovidTestFacade implements SearchInterface {

    protected API api = API.getInstance();
    protected ConsoleText ct = new ConsoleText();

    public void update(String tId){
        HttpResponse<String> response = api.getRequest("/covid-test/" + tId);
        String currentTime = Instant.now().toString();
        JSONObject booking = new JSONObject(response.body());
        String bId = booking.getJSONObject("booking").get("id").toString();
        Scanner input = new Scanner(System.in);
        String testResult, resultString = "";
        // If the test ID is valid
        if (response.statusCode() == 200) {
            boolean condition = false;
            while(!condition) {
                // Display the prompt
                this.updateResultPrompt();
                System.out.print(">> Please enter COVID-Test Result: ");
                testResult = input.nextLine();
                // Verify inputted value
                if (testResult.equals("PE") || testResult.equals("N") || testResult.equals("I") || testResult.equals("PO")){
                    condition = true;
                    switch (testResult) {
                        case "PO" -> resultString = "POSITIVE";
                        case "N"  -> resultString = "NEGATIVE";
                        case "I"  -> resultString = "INVALID";
                        default   -> resultString = "PENDING";
                    }
                }
                else {
                    ct.printBox("(!) Invalid Input! Please refer to the Guide!");
                }
            }
            // Creation of a JSON Object to update test values
            JSONObject updatedTest = new JSONObject()
                    .put("result", resultString)
                    .put("status", "COMPLETED")
                    .put("dateOfResults", currentTime);

            JSONObject updatedBooking = new JSONObject()
                    .put("status", "COMPLETED");

            // Patch Request
            HttpResponse<String> updateResponse = api.patchRequest(updatedTest.toString(), "/covid-test/" + tId);
            HttpResponse<String> updateBooking = api.patchRequest(updatedBooking.toString(), "/booking/" + bId);
            if (updateResponse.statusCode() == 200 && updateBooking.statusCode() == 200){
                ct.printBox("(!) COVID Test Info Successfully Updated!");
                this.displayTestInfo(tId);
            } else {
                ct.printBox("(!) COVID Test Info Failed to Update! Please re-try again!");
            }

        } else {
            ct.printBox("(!) Invalid COVID Test ID! Please re-try again!");
        }

    }

    public void displayTestInfo(String testId){
        this.search(testId, true);
    }

    public void create(String pId, String bId, String aId){
        HttpResponse<String> verifyPID = api.getRequest("/user/" + pId);
        HttpResponse<String> verifyBID = api.getRequest("/booking/" + bId);

        // If both patient ID and booking ID is valid
        if (verifyPID.statusCode() == 200 && verifyBID.statusCode() == 200) {
            // Create a new test
            CovidTest patientTest = new CovidTest(retrievePatient(verifyPID), bId);
            CovidTestView ctView = new CovidTestView();
            CovidTestController ctController = new CovidTestController(patientTest, ctView);
            // Suggestion prompt to determine the test type
            TestType suggestion = covidTestSuggestionPrompt();
            // Set default test values
            this.setTestDefaults(ctController, suggestion, aId);
            // Create a new COVID-Test
            String information = this.createTestJSON(ctController, pId, bId, aId);
            HttpResponse<String> response = api.postRequest(information, "/covid-test");
            // If successful, then we retrieve the ID and display the successful
            // creation prompt and test details
            if (response.statusCode() == 201) {
                JSONObject createdTest = new JSONObject(response.body());
                ctController.setTestId(createdTest.getString("id"));
                patientTest.testCreationSuccessful();
            } // Else, display failure prompt
            else {
                patientTest.testCreationFailure();
            }
        }
        // No such user ID or booking ID exist.
        else {
            ct.printBox("(!) Invalid User.User ID",
                    "AND / OR",
                    "Invalid Booking.Booking ID");
        }
    }


    public TestType covidTestSuggestionPrompt(){

        Map<String, Integer> quesList = new HashMap<>();
        quesList.put("(!) Is the patient's temperature above 37.2 C?", 2);
        quesList.put("(!) Has the patient been in close contact with anyone that is COVID+ in the last 14 days?", 5);
        quesList.put("(!) Has the patient travelled to places with high COVID infection risk in the last 14 days?", 5);
        quesList.put("(!) Is the patient experiencing shortness of breathe issues?", 4);
        quesList.put("(!) Is the patient experiencing congestion or a runny nose?", 2);
        quesList.put("(!) Does the patient have a sore throat?", 2);

        Iterator<Map.Entry<String, Integer>> itr = quesList.entrySet().iterator();

        int risk = 0; String response;
        Scanner input = new Scanner(System.in);
        ct.printBox("(!) COVID Test Type Suggestion Questionnaire",
                "Please direct these questions to the patient AND",
                "fill in their responses with 'Y' as Yes or 'N' as NO.",
                "(Case-Sensitive!)");
        boolean condition;

        while (itr.hasNext()){
            Map.Entry<String, Integer> entry = itr.next();
            ct.printBox(entry.getKey());
            condition = false;
            while (!condition) {
                System.out.print(">> Please input an option: ");
                response = input.nextLine();
                if (response.equals("Y") || response.equals("N")) {
                    condition = true;
                    if (response.equals("Y")) {
                        risk += entry.getValue();
                    }
                } else {
                    ct.printBox("(!) Please enter only 'Y' or 'N'!");
                }
            }
        }
        if (risk >= 6){
            return TestType.PCR;
        }
        return TestType.RAT;
    }

    public User retrievePatient(HttpResponse<String> response){
        // Retrieve patient object based on User.User ID
        JSONObject patient = new JSONObject(response.body());
        String userId      = patient.getString("id");
        String familyName  = patient.getString("familyName");
        String givenName   = patient.getString("givenName");
        String phoneNumber = patient.getString("phoneNumber");
        return UserFactory.getUser(new PatientFactory(familyName, givenName, userId, phoneNumber));
    }

    public void setTestDefaults(CovidTestController testController, TestType suggestion, String aId){
        // Setting the test attributes to default values
        String currentTime = Instant.now().toString();
        testController.setTestType(suggestion);
        testController.setAdministerId(aId);
        testController.setStatus(TestStatus.INITIATED);
        testController.setTestResult(TestResults.PENDING);
        testController.setDateAndTimePerformed(currentTime);
        testController.setDateAndTimeOfUpdate(currentTime);
    }

    public String createTestJSON(CovidTestController testController, String pId, String bId, String aId){
        // Returning a JSON Object with default values
        return new JSONObject()
                .put("type",          testController.getTestType())
                .put("patientId",     pId)
                .put("administererId",aId)
                .put("bookingId",     bId)
                .put("status",        testController.getStatus())
                .put("result",        testController.getTestResult())
                .put("datePerformed", testController.getDateAndTimePerformed())
                .toString();
    }

    public void updateResultPrompt(){
        ct.printBox("COVID Result Input Guide",
                "PE - Pending",
                "N - Negative",
                "I - Invalid",
                "PO - Positive");
    }

    @Override
    public void search(String testId, boolean displayView){
        HttpResponse<String> testResponse = api.getRequest("/covid-test/" + testId);
        JSONObject obj = new JSONObject(testResponse.body());

        String type, pId, administerId, bId, testResult, status, dateCreated, dateOfResults, lastUpdatedAt;
        type          = obj.getString("type");
        pId           = obj.getJSONObject("patient").getString("id");
        administerId  = obj.getJSONObject("administerer").getString("id");
        bId           = obj.getJSONObject("booking").getString("id");
        testResult    = obj.getString("result");
        status        = obj.getString("status");
        dateCreated   = obj.getString("createdAt");
        dateOfResults = obj.getString("dateOfResults");
        lastUpdatedAt = obj.getString("updatedAt");

        if(displayView){
            this.view(testId, type, pId, administerId, bId, testResult, status, dateCreated, dateOfResults, lastUpdatedAt);
        }
    }

    public void view(String tId, String type, String pId, String administerId, String bId, String testResult,
                     String status, String dateCreated, String dateOfResults, String updatedAt){
        ct.printBox("(!) COVID Test Record for User.User.Staff View",
                "COVID Test ID: "              + tId,
                "COVID Test Type: "            + type,
                "COVID Test User Patient ID: "      + pId,
                "COVID Test User Administer ID:  "  + administerId,
                "COVID Test Booking ID: "      + bId,
                "COVID Test Result: "          + testResult,
                "COVID Test Status: "          + status,
                "COVID Test Created At: "      + dateCreated,
                "COVID Test Results Date: "    + dateOfResults,
                "COVID Test Last Updated At: " + updatedAt);
    }
}
