package API;

import Model.Booking.BookingStatus;
import Model.Booking.HomeTestingBooking;
import Model.Booking.OnSiteTestingBooking;
import Model.People.User;
import View.BookingView;
import View.ConsoleText;
import View.HomeTestingBookingView;
import View.UserView;

import org.json.JSONArray;
import org.json.JSONObject;

import Controller.BookingController;
import Controller.HomeTestingBookingController;
import Controller.UserController;

import java.io.IOException;
import java.net.http.HttpResponse;
import java.time.Instant;
import java.time.temporal.ChronoUnit;

/**
 * Facade class for booking
 */
public class BookingFacade implements SearchInterface {

    protected API api = API.getInstance();
    protected ConsoleText ct = new ConsoleText();

    @Override
    public void search(String identifier, boolean displayView) {
        HttpResponse<String> response = api.getRequest("/booking/" + identifier);
        JSONObject obj = new JSONObject(response.body());

        String custId, custFirst, custLast, custPhone, siteId, siteName, smsPin, status, updatedAt, startTime;
        custId    = obj.getJSONObject("customer").getString("id");
        custFirst = obj.getJSONObject("customer").getString("givenName");
        custLast  = obj.getJSONObject("customer").getString("familyName");
        custPhone = obj.getJSONObject("customer").getString("phoneNumber");
        siteId    = obj.getJSONObject("testingSite").getString("id");
        siteName  = obj.getJSONObject("testingSite").getString("name");
        smsPin    = obj.getString("smsPin");
        status    = obj.getString("status");
        updatedAt = obj.getString("updatedAt");
        startTime = obj.getString("startTime");

        if (displayView){
            this.view(identifier, custId, custFirst, custLast, custPhone, siteId, siteName, smsPin, status, updatedAt, startTime);
        }
    }

    public void view(String bookingId, String custId, String custFirst, String custLast, String custPhone, String siteId, String siteName,
                     String smsPin, String status, String updatedAt, String startTime){
        ct.printBox("(!) Booking Record for Staff View",
                "Booking ID: "         + bookingId,
                "Customer ID: "        + custId,
                "Customer Name: "      + custFirst + " " + custLast,
                "Customer Phone: "     + custPhone,
                "Booking Site ID: "    + siteId,
                "Booking Site Name: "  + siteName,
                "Booking SMS PIN: "    + smsPin,
                "Booking Status: "     + status,
                "Booking Updated At: " + updatedAt,
                "Booking Start Time: " + startTime);
    }

    /**
     * Registers the user for ON-SITE booking through web service
     *
     * @param user    user who made the booking
     * @param booking ON-SITE booking object
     * @return a boolean, true if successful, false otherwise
     */
    public boolean registerOnSiteBooking(User user, OnSiteTestingBooking booking) {
        // Initialise MVC components - view and controller
        UserView userView = new UserView();
        BookingView bookingView = new BookingView();
        UserController userController = new UserController(user, userView);
        BookingController bookingController = new BookingController(booking, bookingView);

        String currentTime = Instant.now().plus(1, ChronoUnit.DAYS)
                .toString();
        // Creates a JSON Object to store information in additionalInfo field
        String credentials = this.storeOnSiteAddInfo(bookingController, userController, currentTime);

        HttpResponse<String> response = api
                .postRequest(credentials, "/booking");
        // Once successful, we set the default parameters of a Booking object.
        if (response.statusCode() == 201) {
            JSONObject json = new JSONObject(response.body());
            bookingController.setBookingId(json.getString("id"));
            bookingController.setCreationTime(currentTime);
            bookingController.setUpdatedTime(currentTime);
            bookingController.setStatus(BookingStatus.INITIATED);
            return true;
        } else {
            return false;
        }
    }

    /**
     * Registers the user for HOME booking through web service
     *
     * @param user    user who made the booking
     * @param booking HOME booking object
     * @return a boolean, true if successful, false otherwise
     */
    public boolean registerHomeBooking(User user, HomeTestingBooking booking) {
        // Initialise MVC components - view and controller
        UserView userView = new UserView();
        HomeTestingBookingView bookingView = new HomeTestingBookingView();
        UserController userController = new UserController(user, userView);
        HomeTestingBookingController bookingController = new HomeTestingBookingController(booking, bookingView);

        String currentTime = Instant.now().plus(1, ChronoUnit.DAYS)
                .toString();
        // Creates a JSON Object to store information in additionalInfo field
        String credentials = this.storeHomeAddInfo(bookingController, userController, currentTime);

        HttpResponse<String> response = api
                .postRequest(credentials, "/booking");
        // Once successful, we set the default parameters of a Booking object.
        if (response.statusCode() == 201) {
            JSONObject json = new JSONObject(response.body());
            bookingController.setBookingId(json.getString("id"));
            bookingController.setCreationTime(currentTime);
            bookingController.setUpdatedTime(currentTime);
            bookingController.setStatus(BookingStatus.INITIATED);
            return true;
        } else {
            return false;
        }
    }

    public void pinToBookingID (String pin) throws IOException {
        // Convert from PIN to Booking ID
        HttpResponse<String> response = api.getRequest("/booking");
        String id = api.responseSearch(response, "smsPin", pin, false);
        if (id != null) {
            id = id.substring(1, id.length() - 1);
            ct.printBox("Booking ID: " + id);
        } else {
            ct.printBox("(!) Booking with such Booking PIN is not found! Please re-try!");
        }
    }

    public boolean displayBookingModifications(String identifier){
        // Display the booking modifications that a user has.
        HttpResponse<String> response = api.getRequest("/user/" + identifier);
        if (response.statusCode() == 200){
            String date, type, initial, bId, newV, fId;
            JSONObject obj = new JSONObject(response.body());
            JSONArray arr = obj.getJSONObject("additionalInfo").getJSONArray("modifications");
            for (int i = 0; i < arr.length(); i++){
                JSONObject current = arr.getJSONObject(i);
                date = current.getString("dateModified");
                type = current.getString("type");
                initial = current.getString("initialValue");
                newV = current.getString("newValue");
                fId = current.getString("facilityId");
                bId = current.getString("bookingId");
                ct.printBox("Modification Record (" + (i+1) + ")",
                        "Date Modified: " + date,
                        "Type of Modification: " + type,
                        "Initial Value: " + initial,
                        "Current Value: " + newV,
                        "Booking ID: " + bId,
                        "Facility ID: " + fId);
            }
            if (arr.length() == 0){
                ct.printBox("(!) No modifications found.");
                return false;
            } else {
                return true;
            }
        } else {
            ct.printBox("(!) User does not exist. Please re-try!");
            return false;
        }
    }

    /**
     * Helper function to store information in additionalInfo field for the registerOnSiteBooking method.
     * Creates a JSON string for calling POST. 
     * 
     * @param bookingController
     * @param userController
     * @param currentTime
     * @return a string in JSON format
     */
    public String storeOnSiteAddInfo(BookingController bookingController, UserController userController, String currentTime) {
        JSONObject additionalInfo = new JSONObject()
                .put("bookingType", bookingController.getBookingType());
        String credentials = new JSONObject()
                .put("customerId", userController.getUserId())
                .put("testingSiteId", bookingController.getTestingSiteId())
                .put("startTime", currentTime)
                .put("additionalInfo", additionalInfo)
                .toString();
        
        return credentials;
    }

    /**
     * Helper function to store information in additionalInfo field for the registerHomeBooking method.
     * Creates a JSON string for calling POST. 
     * 
     * @param bookingController
     * @param userController
     * @param currentTime
     * @return a string in JSON format
     */
    public String storeHomeAddInfo(HomeTestingBookingController bookingController, UserController userController, String currentTime){
        JSONObject additionalInfo = new JSONObject().put("bookingType", bookingController.getBookingType());
        if (bookingController.getRequireRAT()) {
            additionalInfo.put("qrCode", bookingController.getQrCode());
            additionalInfo.put("collectedRAT", false);
            additionalInfo.put("requireRAT", true);
        } else {
            additionalInfo.put("siteUrl", bookingController.getSiteURL());
            additionalInfo.put("requireRAT", false);
        }
        String credentials = new JSONObject()
                .put("customerId", userController.getUserId())
                .put("testingSiteId",  bookingController.getTestingSiteId())
                .put("startTime", currentTime)
                .put("additionalInfo", additionalInfo)
                .toString();
        
        return credentials;
    }
}
