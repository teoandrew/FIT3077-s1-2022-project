package API;

import java.io.IOException;
import java.net.http.HttpResponse;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Scanner;

import org.json.JSONArray;
import org.json.JSONObject;

import View.ConsoleText;

/**
 * Facade class for site search
 */
public class SiteSearchFacade {
    private API api = API.getInstance();
    protected ConsoleText ct = new ConsoleText();

    public boolean identifyAvailability(String identifier){
        HttpResponse<String> response = api.getRequest("/testing-site/" + identifier);
        JSONObject obj = new JSONObject(response.body());
        String openTime = obj.getJSONObject("additionalInfo").get("openTime").toString();
        String closeTime = obj.getJSONObject("additionalInfo").get("closeTime").toString();

        LocalTime current = LocalTime.now();
        return current.isAfter(LocalTime.parse(openTime)) && current.isBefore(LocalTime.parse(closeTime));
    }

    public void searchSitePrompt(){
        String option = "";
        Scanner input = new Scanner(System.in);
        boolean valid = false;
        while(!valid) {
            ct.printBox("(!) Filter testing sites by:",
                    "(1) Suburb name",
                    "(2) Testing Sites with Drive Through Service",
                    "(3) Testing Sites with Walk-In Service",
                    "(4) Clinic Testing Sites Only",
                    "(5) GP Testing Sites Only",
                    "(6) Hospital Testing Sites Only",
                    "(7) View all Testing Sites without filter");
            System.out.print(">> Please pick an option: ");
            option = input.nextLine();
            if (option.equals("1") || option.equals("2") || option.equals("3") || option.equals("4")
                    || option.equals("5") || option.equals("6") || option.equals("7")){
                valid = true;
            } else {
                this.displayInvalidPrompt();
            }
        }
        // Searching by suburb name
        switch (option) {
            case "1" -> {
                System.out.print(">> Enter suburb name: ");
                String suburbName = input.nextLine();
                try {
                    this.searchSitesBySuburb(suburbName);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            // Searching by facility types
            case "2" -> this.searchSitesByType(1);
            case "3" -> this.searchSitesByType(2);
            case "4" -> this.searchSitesByType(3);
            case "5" -> this.searchSitesByType(4);
            case "6" -> this.searchSitesByType(5);
            default -> this.viewAllSites();
        }
    }

    public void displayInvalidPrompt(){
        ct.printBox("(!) Invalid Input");
    }

    public void viewAllSites(){
        HttpResponse<String> response = api.getRequest("/testing-site");
        JSONArray jsonArry = new JSONArray(response.body());
        ArrayList<String> id = new ArrayList<>();

        for(int i = 0; i < jsonArry.length(); i++){
            JSONObject objects = jsonArry.getJSONObject(i);
            id.add(objects.getString("id"));
        }
        display(id);
    }

    public void viewAllSiteVenues(){
        HttpResponse<String> response = api.getRequest("/testing-site");
        JSONArray jsonArry = new JSONArray(response.body());
        ArrayList<String> id = new ArrayList<>();

        ct.printBox("(!) All Available Testing Site Venues: ");

        for(int i = 0; i < jsonArry.length(); i++){
            JSONObject objects = jsonArry.getJSONObject(i);
            System.out.println("Testing Site: " + objects.getString("name"));
            System.out.println("Testing Site Area: " + objects.getJSONObject("address").getString("suburb"));
            System.out.println("Testing Site ID: " + objects.getString("id"));
            System.out.println();
        }

        System.out.println("--------------END OF TESTING SITE VENUES--------------\n");
    }

    /**
     * Searches for testing sites based on suburb name provided
     * @param suburbName name of suburb that facility is in
     * made it past filtering. Each piece of information is separated by "/" to parse.
     */
    public void searchSitesBySuburb (String suburbName) throws IOException{

        HttpResponse<String> response = api.getRequest("/testing-site");
        JSONArray jsonArry = new JSONArray(response.body());
        ArrayList<String> id = new ArrayList<>();

        for(int i = 0; i < jsonArry.length(); i++){
            JSONObject objects = jsonArry.getJSONObject(i);
            if (objects.getJSONObject("address").getString("suburb").equalsIgnoreCase(suburbName)){
                id.add(objects.getString("id"));
            }
        }
        display(id);
    }

    public void searchSitesByType(int selection){
        HttpResponse<String> response = api.getRequest("/testing-site");
        JSONArray jsonArry = new JSONArray(response.body());
        ArrayList<String> id = new ArrayList<>();

        String type;
        if (selection == 1){
            type = "isDriveThrough";
        } else if (selection == 2){
            type = "isWalkIn";
        } else if (selection == 3){
            type = "isClinic";
        } else if (selection == 4){
            type = "isGP";
        } else {
            type = "isHospital";
        }

        for(int i = 0; i < jsonArry.length(); i++){
            JSONObject objects = jsonArry.getJSONObject(i);
            if(!objects.getJSONObject("additionalInfo").isEmpty()) {
                if (objects.getJSONObject("additionalInfo").getBoolean(type)){
                    id.add(objects.getString("id"));
                }
            }
        }
        display(id);
    }

    private int getWaitingTimes(String siteId){
        int waitingTime = 15, validBookings = 0;
        HttpResponse<String> bookingResponse = api.getRequest("/testing-site/" + siteId + "?fields=bookings");

        JSONObject obj = new JSONObject(bookingResponse.body());
        JSONArray arr = obj.getJSONArray("bookings");

        for(int i = 0; i< arr.length(); i++){
            if(!arr.getJSONObject(i).getString("status").equals("COMPLETED")){
                validBookings += 1;
            }
        }
        if(validBookings == 0){
            return waitingTime;
        }
        return waitingTime * validBookings;
    }

    private void display(ArrayList<String> idArr){
        ct.printBox("(!) Available Test Sites: ",
                "NOTE: You may not make a booking without login!");
        if (idArr.size() > 0) {
            for (int i = 0; i < idArr.size(); i++) {
                HttpResponse<String> res = api.getRequest("/testing-site/" + idArr.get(i));
                JSONObject json = new JSONObject(res.body());
                String addUnitNumber, addStreet, addStreet2, addSuburb, addState, addPostCode,
                        siteId, siteName, siteDescription = "N/A", siteWebsiteURL = "N/A", sitePhoneNumber, openTime = "N/A", closeTime = "N/A", type;
                boolean hasDriveThru = false, hasWalkIn= false, isClinic= false, isGP= false, hasOnSiteBooking= false, hasOnSiteTesting= false;

                addUnitNumber = json.getJSONObject("address").getString("unitNumber");
                addStreet = json.getJSONObject("address").getString("street");
                if (!json.getJSONObject("address").isNull("street2")) {
                    addStreet2 = json.getJSONObject("address").getString("street2");
                } else {
                    addStreet2 = "N/A";
                }
                addSuburb = json.getJSONObject("address").getString("suburb");
                addPostCode = json.getJSONObject("address").getString("postcode");
                addState = json.getJSONObject("address").getString("state");
                if (!json.getJSONObject("additionalInfo").isNull("openTime")) {
                    openTime = json.getJSONObject("additionalInfo").getString("openTime");
                    closeTime = json.getJSONObject("additionalInfo").getString("closeTime");

                    hasDriveThru = json.getJSONObject("additionalInfo").getBoolean("isDriveThrough");
                    hasWalkIn = json.getJSONObject("additionalInfo").getBoolean("isWalkIn");
                    isClinic = json.getJSONObject("additionalInfo").getBoolean("isClinic");
                    isGP = json.getJSONObject("additionalInfo").getBoolean("isGP");
                    hasOnSiteBooking = json.getJSONObject("additionalInfo").getBoolean("onSiteBooking");
                    hasOnSiteTesting = json.getJSONObject("additionalInfo").getBoolean("onSiteTesting");
                }
                if (isClinic) {
                    type = "Clinic";
                } else if (isGP) {
                    type = "GP";
                } else {
                    type = "Hospital";
                }

                siteId = json.getString("id");
                siteName = json.getString("name");
                if (!json.isNull("description")) {
                    siteDescription = json.getString("description");
                }
                if (!json.isNull("websiteUrl")) {
                    siteWebsiteURL = json.getString("websiteUrl");
                }
                sitePhoneNumber = json.getString("phoneNumber");
                ct.printBox("(!) Test Site (" + (i+1) + ")",
                        "Test Site ID: " + siteId,
                        "Test Site Name: " + siteName,
                        "Test Site Description: " + siteDescription,
                        "Test Site URL: " + siteWebsiteURL,
                        "Test Site Phone Number: " + sitePhoneNumber,
                        "Test Site Type: " + type,
                        "Test Site Address: ",
                        ">> Address Unit: " + addUnitNumber,
                        ">> Address Street: " + addStreet,
                        ">> Address Street 2: " + addStreet2,
                        ">> Address Suburb: " + addSuburb,
                        ">> Address State: " + addState,
                        ">> Address Postcode: " + addPostCode,
                        "Test Site Open Time: " + openTime,
                        "Test Site Close Time: " + closeTime,
                        "Current Test Site Waiting Time: " + this.getWaitingTimes(siteId) + " minutes");

                ct.printBox("(!) Services Available",
                        "Drive Through: " + hasDriveThru,
                        "Walk In: " + hasWalkIn,
                        "On-Site Testing: " + hasOnSiteTesting,
                        "On-Site Booking: " + hasOnSiteBooking);
            }
        }
        else {
            ct.printBox("(!) No Test Sites Available, Please re-search with different terms!");
        }
    }
}
