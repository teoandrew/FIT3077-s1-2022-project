package API;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.ArrayList;

/**
 * API class
 */
public class API {

    public static API api;
    private final String myApiKey = "mgCd6RHggCqgtbqNwJmGmKK8BFdbL7";
    // v1 key: QppLnKNwNmfpcC789TRJkHMdtbgbHm
    // v2 key: HmGgfDBqn9NmM66rrkQJdwwPTf8gGk
    
    private final String rootUrl  = "https://fit3077.com/api/v2";
    private final String usersUrl = rootUrl + "/user";
    private final String loginUrl = usersUrl + "/login";

    public static API getInstance(){
        if(api == null){
            api = new API();
        }
        return api;
    }

    private API(){}

    public String getMyApiKey(){
        return myApiKey;
    }

    public String getRootUrl(){
        return rootUrl;
    }

    public String getUsersUrl(){
        return usersUrl;
    }

    public String getLoginUrl() {
        return loginUrl;
    }

    public HttpResponse<String> postRequest(String input, String urlExtension){
        HttpClient client = HttpClient.newBuilder().build();
        HttpRequest request = HttpRequest.newBuilder(URI.create(this.rootUrl + urlExtension))
                .POST(HttpRequest.BodyPublishers.ofString(input))
                .setHeader("Authorization", this.myApiKey)
                .header("Content-Type", "application/json")
                .build();

        HttpResponse<String> response;
        try {
            response = client.send(request, HttpResponse.BodyHandlers.ofString());
        } catch (IOException | InterruptedException e) {
            throw new RuntimeException(e);
        }

        return response;
    }

    public HttpResponse<String> patchRequest(String input, String urlExtension){
        HttpClient client = HttpClient.newBuilder().build();
        HttpRequest request = HttpRequest.newBuilder(URI.create(this.rootUrl + urlExtension))
                .setHeader("Authorization", this.myApiKey)
                .method("PATCH", HttpRequest.BodyPublishers.ofString(input))
                .header("Content-Type", "application/json")
                .build();

        HttpResponse<String> response;
        try {
            response = client.send(request, HttpResponse.BodyHandlers.ofString());
        } catch (IOException | InterruptedException e) {
            throw new RuntimeException(e);
        }

        return response;
    }

    public HttpResponse<String> deleteRequest(String urlExtension){
        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest.newBuilder(URI.create(this.rootUrl + urlExtension))
                .setHeader("Authorization", this.myApiKey)
                .DELETE()
                .build();

        HttpResponse<String> response;
        try {
            response = client.send(request, HttpResponse.BodyHandlers.ofString());
        } catch (IOException | InterruptedException e) {
            throw new RuntimeException(e);
        }
        return response;
    }

    public HttpResponse<String> getRequest(String urlExtension){
        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest.newBuilder(URI.create(this.rootUrl + urlExtension))
                .setHeader("Authorization", this.myApiKey)
                .GET()
                .build();

        HttpResponse<String> response;
        try {
            response = client.send(request, HttpResponse.BodyHandlers.ofString());
        } catch (IOException | InterruptedException e) {
            throw new RuntimeException(e);
        }
        return response;
    }

    public HttpResponse<String> getRequestParamQuery(String urlExtension, ArrayList<String> queryParams){
        String uriString = this.rootUrl + urlExtension + "?";

        for (int i = 0; i < queryParams.size()-1; i++) {
            uriString += "fields=";
            uriString += queryParams.get(i);
            uriString += "&";
        }

        uriString += "fields=";
        uriString += queryParams.get(queryParams.size()-1);

        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest.newBuilder(URI.create(uriString))
                .setHeader("Authorization", this.myApiKey)
                .GET()
                .build();

        HttpResponse<String> response;
        try {
            response = client.send(request, HttpResponse.BodyHandlers.ofString());
        } catch (IOException | InterruptedException e) {
            throw new RuntimeException(e);
        }
        return response;
    }

    public String extractID(ObjectNode[] jsonNodes, int identifier){
        return jsonNodes[identifier].get("id").toString();
    }

    public String responseSearch(HttpResponse<String> response, String identifier, String providedValue, boolean isInAdditional) throws IOException {
        boolean condition = false;
        int i = 0, num = -1;
        ObjectNode[] jsonNodes = new ObjectMapper().readValue(response.body(), ObjectNode[].class);

        if (isInAdditional) {
            while (!condition && i < jsonNodes.length) {
                if (jsonNodes[i].get("additionalInfo").get(identifier) != null) {
                    if (jsonNodes[i].get("additionalInfo").get(identifier).toString().equals('"' + providedValue + '"')) {
                        condition = true;
                        num = i;
                    }
                }
                i++;
            }
        } else {
            while(!condition && i < jsonNodes.length) {
                if(jsonNodes[i].get(identifier) != null){
                    if(jsonNodes[i].get(identifier).toString().equals('"' + providedValue + '"')) {
                        condition = true;
                        num = i;
                    }
                }
                i ++;
            }
        }
        if(num != -1){
            return extractID(jsonNodes, num);
        } else{
            return null;
        }

    }

}
