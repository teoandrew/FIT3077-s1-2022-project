package Controller;

import Model.People.Account;
import Model.People.User;
import View.UserView;

/**
 * Controller class for managing User model and view
 */
public class UserController {
    
    private User model;
    private UserView view;

    public UserController(User model, UserView view){
        this.model = model;
        this.view = view;
    }

    public Account getUserAcc() {
        return model.getUserAcc();
    }

    public String getUserId() {
        return model.getUserId();
    }

    public String getFamilyName() {
        return model.getFamilyName();
    }

    public String getGivenName() {
        return model.getGivenName();
    }

    public String getPhoneNumber() {
        return model.getPhoneNumber();
    }

    public void viewUpdate(){
        view.printUserDetails();
    }
}
