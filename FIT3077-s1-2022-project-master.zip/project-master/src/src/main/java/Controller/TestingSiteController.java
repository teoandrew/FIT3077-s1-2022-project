package Controller;

import Model.TestingSite.Address;
import Model.TestingSite.TestingSite;
import View.TestingSiteView;

/**
 * Controller class for managing TestingSite model and view
 */
public class TestingSiteController {

    protected TestingSite model;
    protected TestingSiteView view;

    public TestingSiteController(TestingSite model, TestingSiteView view) {
        this.model = model;
        this.view = view;
    }

    public String getSiteId() {
        return model.getSiteId();
    }

    public void setSiteId(String siteId) {
        model.setSiteId(siteId);
    }

    public String getSiteName() {
        return model.getSiteName();
    }

    public void setSiteName(String siteName) {
        model.setSiteName(siteName);
    }

    public Address getSiteAddress() {
        return model.getSiteAddress();
    }

    public void setSiteAddress(Address siteAddress) {
        model.setSiteAddress(siteAddress);
    }

    public boolean getIsDriveThrough() {
        return model.getIsDriveThrough();
    }

    public void setIsDriveThrough(boolean isDriveThrough) {
        model.setIsDriveThrough(isDriveThrough);
    }

    public boolean getIsWalkIn() {
        return model.getIsWalkIn();
    }

    public void setIsWalkIn(boolean isWalkIn) {
        model.setIsWalkIn(isWalkIn);
    }

    public boolean getIsClinic() {
        return model.getIsClinic();
    }

    public void setIsClinic(boolean isClinic) {
        model.setIsClinic(isClinic);
    }

    public boolean getIsGP() {
        return model.getIsGP();
    }

    public void setIsGP(boolean isGP) {
        model.setIsGP(isGP);
    }

    public boolean getIsHospital() {
        return model.getIsHospital();
    }

    public void setIsHospital(boolean isHospital) {
        model.setIsHospital(isHospital);
    }

    public void viewUpdate(){
        view.printTestingSiteDetails();
    }
}
