package Controller;
import Model.Booking.BookingUpdateObserver;
import View.BookingUpdateObserverView;

/**
 * Observer class for updating Booking through the controller
 */
public class BookingUpdateObserverController {

    protected BookingUpdateObserver model;
    protected BookingUpdateObserverView view;

    public BookingUpdateObserverController(BookingUpdateObserver model, BookingUpdateObserverView view){
        this.model = model;
        this.view = view;
    }

    /**
     * Updates our model to retrieve real time updates or creations of our bookings.
     */
    public void update(){
        this.model.update();
    }

    /**
     * Obtain booking updates from our View
     */
    public void updateView(){
        this.view.view(this.model.getSortedBookings(), this.model.getSortedModifications(), this.model.getSortedDeletions(), this.model.getSortedReverts());
    }


}
