package Controller;

import Model.CovidTesting.CovidTest;
import Model.CovidTesting.TestResults;
import Model.CovidTesting.TestStatus;
import Model.CovidTesting.TestType;
import Model.People.User;
import View.CovidTestView;

/**
 * Controller class for managing CovidTest model and view
 */
public class CovidTestController {
    
    protected CovidTest model;
    protected CovidTestView view;

    public CovidTestController(CovidTest model, CovidTestView view){
        this.model = model;
        this.view = view;
    }

    public void setTestId(String testId) {
        model.setTestId(testId);
    }

    public String getTestId() {
        return model.getTestId();
    }

    public String getBookingId() {
        return model.getBookingId();
    }

    public void setBookingId(String bookingId) {
        model.setBookingId(bookingId);
    }

    public void setPatient(User patient){
        model.setPatient(patient);
    }

    public User getPatient() {
        return model.getPatient();
    }

    public void setTestResult(TestResults testResult) {
        model.setTestResult(testResult);
    }

    public TestResults getTestResult() {
        return model.getTestResult();
    }

    public void setAdministerId(String administerId) {
        model.setAdministerId(administerId);
    }

    public void setDateAndTimeOfResults(String dateAndTimeOfResults) {
        model.setDateAndTimeOfResults(dateAndTimeOfResults);
    }

    public void setDateAndTimeOfUpdate(String dateAndTimeOfUpdate) {
        model.setDateAndTimeOfUpdate(dateAndTimeOfUpdate);
    }

    public void setDateAndTimePerformed(String dateAndTimePerformed) {
        model.setDateAndTimePerformed(dateAndTimePerformed);
    }

    public void setStatus(TestStatus status) {
        model.setStatus(status);
    }

    public void setTestType(TestType testType) {
        model.setTestType(testType);
    }

    public String getAdministerId() {
        return model.getAdministerId();
    }

    public String getDateAndTimeOfResults() {
        return model.getDateAndTimeOfResults();
    }

    public String getDateAndTimeOfUpdate() {
        return model.getDateAndTimeOfUpdate();
    }

    public String getDateAndTimePerformed() {
        return model.getDateAndTimePerformed();
    }

    public TestStatus getStatus() {
        return model.getStatus();
    }

    public TestType getTestType() {
        return model.getTestType();
    }
    
    public void viewUpdate(){
        view.printCovidTestDetails();
    }
}
