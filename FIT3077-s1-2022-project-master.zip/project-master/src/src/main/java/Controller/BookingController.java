package Controller;

import Model.Booking.Booking;
import Model.Booking.BookingStatus;
import Model.Booking.BookingType;
import Model.People.User;
import View.BookingView;

/**
 * Controller class for managing Booking model and view
 */
public class BookingController {
    
    protected Booking model;
    protected BookingView view;

    public BookingController(Booking model, BookingView view){
        this.model = model;
        this.view = view;
    }

    public void setBookingType(BookingType bookingType) {
        model.setBookingType(bookingType);
    }

    public void setBookingId(String bookingId){
        model.setBookingId(bookingId);
    }

    public void setStatus(BookingStatus status){
        model.setStatus(status);
    }

    public void setCreationTime(String creationTime) {
        model.setCreationTime(creationTime);
    }

    public void setUpdatedTime(String updatedTime) {
        model.setUpdatedTime(updatedTime);
    }

    public String getBookingId(){
        return model.getBookingId();
    }

    public BookingStatus getStatus() {
        return model.getStatus();
    }

    public String getCreationTime() {
        return model.getCreationTime();
    }

    public String getUpdatedTime() {
        return model.getUpdatedTime();
    }

    public BookingType getBookingType() {
        return model.getBookingType();
    }

    public User getCustomer() {
        return model.getCustomer();
    }

    public String getTestingSiteId() {
        return model.getTestingSiteId();
    }

    public int getChangeHistoryNo() {
        return model.getChangeHistoryNo();
    }

    public int setChangeHistoryNo() {
        return model.setChangeHistoryNo();
    }

    public void viewUpdate(){
        view.printBookingDetails();
    }
}
