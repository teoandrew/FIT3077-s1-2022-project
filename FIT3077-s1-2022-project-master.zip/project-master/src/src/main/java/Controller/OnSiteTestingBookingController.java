package Controller;

import Model.Booking.BookingStatus;
import Model.Booking.BookingType;
import Model.Booking.OnSiteTestingBooking;
import Model.People.User;
import View.OnSiteTestingBookingView;

/**
 * Controller class for managing OnSiteTestingBooking model and view
 */
public class OnSiteTestingBookingController {

    protected OnSiteTestingBooking model;
    protected OnSiteTestingBookingView view;

    public OnSiteTestingBookingController(OnSiteTestingBooking model, OnSiteTestingBookingView view) {
        this.model = model;
        this.view = view;
    }

    public void setBookingType(BookingType bookingType) {
        model.setBookingType(bookingType);
    }

    public void setBookingId(String bookingId){
        model.setBookingId(bookingId);
    }

    public void setStatus(BookingStatus status){
        model.setStatus(status);
    }

    public void setCreationTime(String creationTime) {
        model.setCreationTime(creationTime);
    }

    public void setUpdatedTime(String updatedTime) {
        model.setUpdatedTime(updatedTime);
    }

    public String getBookingId(){
        return model.getBookingId();
    }

    public BookingStatus getStatus() {
        return model.getStatus();
    }

    public String getCreationTime() {
        return model.getCreationTime();
    }

    public String getUpdatedTime() {
        return model.getUpdatedTime();
    }

    public BookingType getBookingType() {
        return model.getBookingType();
    }

    public User getCustomer() {
        return model.getCustomer();
    }

    public String getTestingSiteId() {
        return model.getTestingSiteId();
    }

    public void setPinCode(String pinCode) {
        model.setPinCode(pinCode);
    }

    public String getPinCode() {
        return model.getPinCode();
    }
    
    public void viewUpdate(){
        view.printOnSiteTestingBookingDetails();
    }
}
